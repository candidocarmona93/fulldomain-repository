<div data-dialog-backdrop="<?php echo e($name); ?>" data-dialog-backdrop-close="true" class="pointer-events-none fixed inset-0 z-[999] grid h-screen w-screen place-items-center bg-black bg-opacity-60 opacity-0 backdrop-blur-sm transition-opacity duration-300 loading-show">
    <div data-dialog="<?php echo e($name); ?>" class="modal-container px-8 py-5 w-full mx-5 my-auto rounded-lg bg-white shadow-md transition ease-in-out <?php echo e($maxWidth ?? 'max-w-4xl'); ?> <?php echo e($maxHeight ?? 'max-h-auto'); ?> <?php echo e($classes ?? ''); ?>">
        <div class="relative">
            <button class="hover:text-slate-700 inset-y-0 right-0 text-[#222] ms-auto block" data-ripple-dark="true" data-dialog-close="true">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
                    <path fill-rule="evenodd" d="M5.47 5.47a.75.75 0 011.06 0L12 10.94l5.47-5.47a.75.75 0 111.06 1.06L13.06 12l5.47 5.47a.75.75 0 11-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 010-1.06z" clip-rule="evenodd"></path>
                </svg>
            </button>
        </div>
        <div class="model-body py-5">
            <?php echo e($body); ?>

        </div>
    </div>
</div>
<style>
    .modal-container {
        transition: all 0.3s ease;
    }
    .modal-enter-from {
        opacity: 0;
    }
    .modal-leave-to {
        opacity: 0;
    }
    .modal-enter-from .modal-container,
    .modal-leave-to .modal-container {
        -webkit-transform: scale(1.1);
        transform: scale(1.1);
    }
</style>
<?php /**PATH /home/casacoim/imoveis.casacoimbramaputo.com/resources/views/components/modal/default.blade.php ENDPATH**/ ?>