<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <?php echo SEOMeta::generate(); ?>

        <?php echo OpenGraph::generate(); ?>

        <?php echo Twitter::generate(); ?>

        <?php echo JsonLd::generate(); ?>

        <link rel="stylesheet" href="<?php echo e(asset('./plugins/jquery.datetimepicker/jquery.datetimepicker.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('./css/app.css')); ?>">
        <!-- from cdn -->
        <script src="https://unpkg.com/@material-tailwind/html@latest/scripts/dialog.js"></script>
        <script src="<?php echo e(asset('./js/app.js')); ?>"></script>
    </head>
    <body>
        <slot />
    </body>
</html>
<?php /**PATH D:\XBoost\imoveis\resources\views/layouts/app.blade.php ENDPATH**/ ?>