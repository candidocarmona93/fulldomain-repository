<?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php $__currentLoopData = $immobiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $immobile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="relative p-5 loading-show">
        <div class="bg-gray-900/30 rounded-lg top-5 absolute bottom-0 left-5 right-5" style="height: calc(100vh - 110px);"></div>
        <img class="rounded-lg object-cover w-full" style="height: calc(100vh - 110px);" src="https://workspace.casacoimbramaputo.com/uploads/immobiles/<?php echo e($immobile->code); ?>/<?php echo e($immobile->picture); ?>" alt="<?php echo e($immobile->title); ?>">
        <div class="absolute px-10 text-lg text-white bottom-0 lg:py-5 py-16 right-5 left-5">
            <div class="lg:flex lg:flex-row lg:gap-2 lg:items-center">
                <img class="lg:block hidden" src="https://workspace.casacoimbramaputo.com/uploads/profiles/agents/<?php echo e($immobile->responsible->picture); ?>" alt="<?php echo e($immobile->responsible->name); ?>">
                <div class="lg:space-y-5 space-y-3 w-full">
                    <h5 class="font-semibold sm:text-4xl text-2xl"><?php echo e($immobile->title); ?></h5>
                    <hr class="h-1 w-12 bg-gradient-to-r from-blue-700 from-35% to-blue-500 to-65% border-0 rounded dark:bg-gray-70 flex-shrink-0">
                    <div class="flex items-center gap-2">
                        <?php if (isset($component)) { $__componentOriginalb83d52f7eeacc0dbad9da1d3f55b955a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb83d52f7eeacc0dbad9da1d3f55b955a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.map-pin-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.map-pin-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb83d52f7eeacc0dbad9da1d3f55b955a)): ?>
<?php $attributes = $__attributesOriginalb83d52f7eeacc0dbad9da1d3f55b955a; ?>
<?php unset($__attributesOriginalb83d52f7eeacc0dbad9da1d3f55b955a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb83d52f7eeacc0dbad9da1d3f55b955a)): ?>
<?php $component = $__componentOriginalb83d52f7eeacc0dbad9da1d3f55b955a; ?>
<?php unset($__componentOriginalb83d52f7eeacc0dbad9da1d3f55b955a); ?>
<?php endif; ?>
                        <span class="text-base break-all"><?php echo e($immobile->address); ?></span>
                    </div>
                    <div class="grid grid-cols-12 sm:space-y-0 space-y-2">
                        <div class="xl:col-span-2 md:col-span-3 sm:col-span-2 col-span-12">
                            <div class="flex items-center gap-1 hover:underline">
                                <?php if (isset($component)) { $__componentOriginal7e508e0ae2c71fd5977618c08090897c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e508e0ae2c71fd5977618c08090897c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.whatsapp-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.whatsapp-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e508e0ae2c71fd5977618c08090897c)): ?>
<?php $attributes = $__attributesOriginal7e508e0ae2c71fd5977618c08090897c; ?>
<?php unset($__attributesOriginal7e508e0ae2c71fd5977618c08090897c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e508e0ae2c71fd5977618c08090897c)): ?>
<?php $component = $__componentOriginal7e508e0ae2c71fd5977618c08090897c; ?>
<?php unset($__componentOriginal7e508e0ae2c71fd5977618c08090897c); ?>
<?php endif; ?>
                                <a href="https://wa.me/+258840169593?text=https://casacoimbramaputo.com/imoveis/<?php echo e($immobile->slug); ?>" target="__blank">
                                    <span class="text-base break-all">+258 84 016 9593</span>
                                </a>
                            </div>
                        </div>
                        <div class="xl:col-span-8 md:col-span-7 sm:col-span-8 col-span-12">
                            <a href='mailto:info@casacoimbramaputo.com' class="flex items-center gap-2 hover:underline">
                                <?php if (isset($component)) { $__componentOriginalf3aea3cd4dde3e5f32847001d37dd4e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3aea3cd4dde3e5f32847001d37dd4e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.envelope-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.envelope-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3aea3cd4dde3e5f32847001d37dd4e9)): ?>
<?php $attributes = $__attributesOriginalf3aea3cd4dde3e5f32847001d37dd4e9; ?>
<?php unset($__attributesOriginalf3aea3cd4dde3e5f32847001d37dd4e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3aea3cd4dde3e5f32847001d37dd4e9)): ?>
<?php $component = $__componentOriginalf3aea3cd4dde3e5f32847001d37dd4e9; ?>
<?php unset($__componentOriginalf3aea3cd4dde3e5f32847001d37dd4e9); ?>
<?php endif; ?>
                                <span class="text-base break-all">info@casacoimbramaputo.com</span>
                            </a>
                        </div>
                        <div class="xl:col-span-2 md:col-span-2 sm:col-span-2 col-span-12">
                            <div class="flex flex-row items-center gap-1 sm:justify-end">
                                <?php if (isset($component)) { $__componentOriginal1ab00d72be62d413783d6e576cc51eed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ab00d72be62d413783d6e576cc51eed = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.eye-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.eye-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ab00d72be62d413783d6e576cc51eed)): ?>
<?php $attributes = $__attributesOriginal1ab00d72be62d413783d6e576cc51eed; ?>
<?php unset($__attributesOriginal1ab00d72be62d413783d6e576cc51eed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ab00d72be62d413783d6e576cc51eed)): ?>
<?php $component = $__componentOriginal1ab00d72be62d413783d6e576cc51eed; ?>
<?php unset($__componentOriginal1ab00d72be62d413783d6e576cc51eed); ?>
<?php endif; ?>
                                <span class="text-base break-all"><?php echo e($immobile->views); ?> Visita(s)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mt-5 loading-show">
        <div class="container mx-auto mb-8">
            <div class="space-x-5 flex md:mx-0 sm:mx-5 mx-5">
                <a href="https://casacoimbramaputo.com" class="font-bold mb-0 cursor-pointer flex gap-1 items-center">
                    <?php if (isset($component)) { $__componentOriginal29d2d09eab1305a5a4e421d03edf1712 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal29d2d09eab1305a5a4e421d03edf1712 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.arrow-small-left-icon','data' => ['class' => 'w-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.arrow-small-left-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal29d2d09eab1305a5a4e421d03edf1712)): ?>
<?php $attributes = $__attributesOriginal29d2d09eab1305a5a4e421d03edf1712; ?>
<?php unset($__attributesOriginal29d2d09eab1305a5a4e421d03edf1712); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal29d2d09eab1305a5a4e421d03edf1712)): ?>
<?php $component = $__componentOriginal29d2d09eab1305a5a4e421d03edf1712; ?>
<?php unset($__componentOriginal29d2d09eab1305a5a4e421d03edf1712); ?>
<?php endif; ?>
                    Voltar
                </a>
                <a class="text-base mb-0"><?php echo e($immobile->title); ?></a>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal95dbe0677c992f5a27f7be25f2eb556a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal95dbe0677c992f5a27f7be25f2eb556a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.gallery','data' => ['code' => $immobile->code,'items' => $gallery]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['code' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->code),'items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($gallery)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal95dbe0677c992f5a27f7be25f2eb556a)): ?>
<?php $attributes = $__attributesOriginal95dbe0677c992f5a27f7be25f2eb556a; ?>
<?php unset($__attributesOriginal95dbe0677c992f5a27f7be25f2eb556a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal95dbe0677c992f5a27f7be25f2eb556a)): ?>
<?php $component = $__componentOriginal95dbe0677c992f5a27f7be25f2eb556a; ?>
<?php unset($__componentOriginal95dbe0677c992f5a27f7be25f2eb556a); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalb8ec376ef52b89c4c912375024511df0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb8ec376ef52b89c4c912375024511df0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar-sticker','data' => ['title' => $immobile->title,'url' => $immobile->slug,'image' => 'https://workspace.casacoimbramaputo.com/uploads/immobiles/'.$immobile->code.'/'.$immobile->picture]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-sticker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->title),'url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->slug),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('https://workspace.casacoimbramaputo.com/uploads/immobiles/'.$immobile->code.'/'.$immobile->picture)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb8ec376ef52b89c4c912375024511df0)): ?>
<?php $attributes = $__attributesOriginalb8ec376ef52b89c4c912375024511df0; ?>
<?php unset($__attributesOriginalb8ec376ef52b89c4c912375024511df0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb8ec376ef52b89c4c912375024511df0)): ?>
<?php $component = $__componentOriginalb8ec376ef52b89c4c912375024511df0; ?>
<?php unset($__componentOriginalb8ec376ef52b89c4c912375024511df0); ?>
<?php endif; ?>
        <div class="container mx-auto sm:px-1 mt-7 mb-14">
            <div class="button-mobile flex md:hidden mb-5 gap-3">
                <button type="button" class="flex items-center justify-center gap-2 sm:mx-0 mx-5 px-4 py-2 text-sm font-medium text-white bg-[#1484FF] rounded-lg hover:bg-blue-600 focus:ring-0 focus:outline-none dark:bg-blue-600 dark:hover:bg-blue-500 dark:focus:ring-blue-800" data-ripple-light="true" data-dialog-target="scheduling">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
                        <path d="M12.75 12.75a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM7.5 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM8.25 17.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM9.75 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM10.5 17.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM12.75 17.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM14.25 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM15 17.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM16.5 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM15 12.75a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM16.5 13.5a.75.75 0 100-1.5.75.75 0 000 1.5z"></path>
                        <path fill-rule="evenodd" d="M6.75 2.25A.75.75 0 017.5 3v1.5h9V3A.75.75 0 0118 3v1.5h.75a3 3 0 013 3v11.25a3 3 0 01-3 3H5.25a3 3 0 01-3-3V7.5a3 3 0 013-3H6V3a.75.75 0 01.75-.75zm13.5 9a1.5 1.5 0 00-1.5-1.5H5.25a1.5 1.5 0 00-1.5 1.5v7.5a1.5 1.5 0 001.5 1.5h13.5a1.5 1.5 0 001.5-1.5v-7.5z" clip-rule="evenodd"></path>
                    </svg> Agendar visita
                </button>
                <button type="button" class="flex items-center gap-2 border text-white bg-[#1484FF] hover:text-white transition-all ease-in-out rounded-lg px-4 py-1 hover:bg-blue-600 focus:ring-0 focus:outline-none dark:bg-blue-600 dark:hover:bg-blue-500 dark:focus:ring-blue-800" data-ripple-light="true" data-dialog-target="share">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186l9.566-5.314m-9.566 7.5l9.566 5.314m0 0a2.25 2.25 0 103.935 2.186 2.25 2.25 0 00-3.935-2.186zm0-12.814a2.25 2.25 0 103.933-2.185 2.25 2.25 0 00-3.933 2.185z"></path>
                    </svg> Partilhar
                </button>
            </div>

            <div class="grid grid-cols-12 sm:mx-0 mx-5">
                <div class="col-span-8 space-y-7">
                    <div class="text-base font-normal">
                        <?php echo $immobile->description; ?>

                    </div>
                    <hr class="sm:block hidden">
                    <?php if (isset($component)) { $__componentOriginal13eb2914ee01d6d4477246b51fb3579d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13eb2914ee01d6d4477246b51fb3579d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.comfort','data' => ['car' => $immobile->car,'pool' => $immobile->pool,'cave' => $immobile->cave,'wifi' => $immobile->wifi,'park' => $immobile->park,'kitchen' => $immobile->kitchen,'pantry' => $immobile->pantry,'electricOven' => $immobile->electric_oven,'gym' => $immobile->gym,'laundry' => $immobile->laundry,'balcony' => $immobile->balcony,'serviceArea' => $immobile->service_area,'cctv' => $immobile->cctv,'equippedKitchen' => $immobile->equipped_kitchen,'suit' => $immobile->suit,'acclimatized' => $immobile->acclimatized,'generator' => $immobile->generator,'guard' => $immobile->guard,'twentyForHourSecurity' => $immobile->twenty_for_hour_security,'receptionArea' => $immobile->reception_area,'livingRoom' => $immobile->living_room,'terrace' => $immobile->terrace,'buildInStove' => $immobile->build_in_stove,'elevator' => $immobile->elevator,'desk' => $immobile->desk,'courtyard' => $immobile->courtyard,'attachments' => $immobile->attachments,'garden' => $immobile->garden,'furnished' => $immobile->furnished]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('comfort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['car' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->car),'pool' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->pool),'cave' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->cave),'wifi' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->wifi),'park' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->park),'kitchen' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->kitchen),'pantry' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->pantry),'electricOven' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->electric_oven),'gym' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->gym),'laundry' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->laundry),'balcony' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->balcony),'serviceArea' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->service_area),'cctv' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->cctv),'equippedKitchen' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->equipped_kitchen),'suit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->suit),'acclimatized' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->acclimatized),'generator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->generator),'guard' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->guard),'twentyForHourSecurity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->twenty_for_hour_security),'receptionArea' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->reception_area),'livingRoom' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->living_room),'terrace' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->terrace),'buildInStove' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->build_in_stove),'elevator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->elevator),'desk' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->desk),'courtyard' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->courtyard),'attachments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->attachments),'garden' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->garden),'furnished' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->furnished)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13eb2914ee01d6d4477246b51fb3579d)): ?>
<?php $attributes = $__attributesOriginal13eb2914ee01d6d4477246b51fb3579d; ?>
<?php unset($__attributesOriginal13eb2914ee01d6d4477246b51fb3579d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13eb2914ee01d6d4477246b51fb3579d)): ?>
<?php $component = $__componentOriginal13eb2914ee01d6d4477246b51fb3579d; ?>
<?php unset($__componentOriginal13eb2914ee01d6d4477246b51fb3579d); ?>
<?php endif; ?>
                </div>
                <div class="col-span-4 mx-auto md:block hidden">
                    <?php if (isset($component)) { $__componentOriginal4ad538da8014c3877354dbed7714ac2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ad538da8014c3877354dbed7714ac2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-scheduling-visits','data' => ['slug' => $immobile->slug]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-scheduling-visits'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->slug)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ad538da8014c3877354dbed7714ac2f)): ?>
<?php $attributes = $__attributesOriginal4ad538da8014c3877354dbed7714ac2f; ?>
<?php unset($__attributesOriginal4ad538da8014c3877354dbed7714ac2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ad538da8014c3877354dbed7714ac2f)): ?>
<?php $component = $__componentOriginal4ad538da8014c3877354dbed7714ac2f; ?>
<?php unset($__componentOriginal4ad538da8014c3877354dbed7714ac2f); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="sm:mx-0 mx-5">
                <hr class="my-7">
                <?php if (isset($component)) { $__componentOriginalfe4855bb643954c83a0cbd6710da1102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe4855bb643954c83a0cbd6710da1102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.comment','data' => ['comments' => '0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('comment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['comments' => '0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe4855bb643954c83a0cbd6710da1102)): ?>
<?php $attributes = $__attributesOriginalfe4855bb643954c83a0cbd6710da1102; ?>
<?php unset($__attributesOriginalfe4855bb643954c83a0cbd6710da1102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe4855bb643954c83a0cbd6710da1102)): ?>
<?php $component = $__componentOriginalfe4855bb643954c83a0cbd6710da1102; ?>
<?php unset($__componentOriginalfe4855bb643954c83a0cbd6710da1102); ?>
<?php endif; ?>
                <hr class="my-7 w-full">
            </div>
            <section class="space-y-3" id="localizacao">
                <h3 class="text-2xl font-semibold text-[#222] sm:mx-0 mx-5">Onde estará</h3>
                <h3 class="text-base text-[#222] sm:mx-0 mx-5"><?php echo e($immobile->address); ?></h3>
                <div class="map">
                    <?php if (isset($component)) { $__componentOriginal3b7e354dcdd3301b3678afd5ba651ae5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b7e354dcdd3301b3678afd5ba651ae5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.map-view','data' => ['lat' => $immobile->latitude,'long' => $immobile->longitude]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('map-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['lat' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->latitude),'long' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->longitude)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b7e354dcdd3301b3678afd5ba651ae5)): ?>
<?php $attributes = $__attributesOriginal3b7e354dcdd3301b3678afd5ba651ae5; ?>
<?php unset($__attributesOriginal3b7e354dcdd3301b3678afd5ba651ae5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b7e354dcdd3301b3678afd5ba651ae5)): ?>
<?php $component = $__componentOriginal3b7e354dcdd3301b3678afd5ba651ae5; ?>
<?php unset($__componentOriginal3b7e354dcdd3301b3678afd5ba651ae5); ?>
<?php endif; ?>
                </div>
            </section>
        </div>
        <div class="bg-[#F7F7F7] py-6 border-t-2 border-t-[#DDD]">
            <div class="container mx-auto">
                <span class="sm:mx-0 mx-5 flex items-center gap-1">
                    <a href="/" class="text-sm">Casa Coimbra Maputo</a>
                    <?php if (isset($component)) { $__componentOriginal04b29e5eea519bfd79b75b598b243e72 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04b29e5eea519bfd79b75b598b243e72 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.chevron-right-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.chevron-right-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04b29e5eea519bfd79b75b598b243e72)): ?>
<?php $attributes = $__attributesOriginal04b29e5eea519bfd79b75b598b243e72; ?>
<?php unset($__attributesOriginal04b29e5eea519bfd79b75b598b243e72); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04b29e5eea519bfd79b75b598b243e72)): ?>
<?php $component = $__componentOriginal04b29e5eea519bfd79b75b598b243e72; ?>
<?php unset($__componentOriginal04b29e5eea519bfd79b75b598b243e72); ?>
<?php endif; ?>
                    <span class="text-sm"><?php echo e($immobile->address); ?></span>
                </span>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal2e26927cdfb99f30fef35f337c57a089 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e26927cdfb99f30fef35f337c57a089 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.default','data' => ['name' => 'scheduling','maxWidth' => 'max-w-xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'scheduling','maxWidth' => 'max-w-xl']); ?>
         <?php $__env->slot('body', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal4ad538da8014c3877354dbed7714ac2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ad538da8014c3877354dbed7714ac2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-scheduling-visits','data' => ['maxwidth' => 'w-full','cborder' => 'border-0','slug' => $immobile->slug]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-scheduling-visits'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxwidth' => 'w-full','cborder' => 'border-0','slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($immobile->slug)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ad538da8014c3877354dbed7714ac2f)): ?>
<?php $attributes = $__attributesOriginal4ad538da8014c3877354dbed7714ac2f; ?>
<?php unset($__attributesOriginal4ad538da8014c3877354dbed7714ac2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ad538da8014c3877354dbed7714ac2f)): ?>
<?php $component = $__componentOriginal4ad538da8014c3877354dbed7714ac2f; ?>
<?php unset($__componentOriginal4ad538da8014c3877354dbed7714ac2f); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e26927cdfb99f30fef35f337c57a089)): ?>
<?php $attributes = $__attributesOriginal2e26927cdfb99f30fef35f337c57a089; ?>
<?php unset($__attributesOriginal2e26927cdfb99f30fef35f337c57a089); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e26927cdfb99f30fef35f337c57a089)): ?>
<?php $component = $__componentOriginal2e26927cdfb99f30fef35f337c57a089; ?>
<?php unset($__componentOriginal2e26927cdfb99f30fef35f337c57a089); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<script>
    // $(document).ready(function() {
    //     setTimeout(function(){
    //         $(".animate-pulse").remove();
    //         $(".loading-show").css('display', 'grid');
    //     }, 5000);
    // })
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XBoost\imoveis\resources\views/immobile.blade.php ENDPATH**/ ?>