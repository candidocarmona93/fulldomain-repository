<div>
    <div class="top-0 bottom-0 right-0 left-0 h-[450px] z-[1]" id="mapContainer"></div>
</div>
<link rel="stylesheet" href="<?php echo e(asset('./plugins/leaflet/leaflet.css')); ?>">
<script src="<?php echo e(asset('./plugins/leaflet/leaflet.js')); ?>"></script>
<script>
    $(document).ready(function() {
        var lat = <?php echo e($lat ?? -25.9619408); ?>

        var long = <?php echo e($long ?? 32.4748737); ?>


        var container = L.map('mapContainer', {
                zoomControl: false
            }).setView([lat, long], 15);

        L.tileLayer('https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, Implementation &copy; <a href="https://www.legocode.com/">Legocode</a>',
            maxZoom: 18,
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
        }).addTo(container);

        L.control.zoom({
            position: 'topright'
        }).addTo(container);

        if(lat && long) {
            L.marker([lat, long])
            .addTo(container)
            .bindTooltip(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" class="h-7"><path d="M11.47 3.84a.75.75 0 011.06 0l8.69 8.69a.75.75 0 101.06-1.06l-8.689-8.69a2.25 2.25 0 00-3.182 0l-8.69 8.69a.75.75 0 001.061 1.06l8.69-8.69z"></path><path d="M12 5.432l8.159 8.159c.03.03.06.058.091.086v6.198c0 1.035-.84 1.875-1.875 1.875H15a.75.75 0 01-.75-.75v-4.5a.75.75 0 00-.75-.75h-3a.75.75 0 00-.75.75V21a.75.75 0 01-.75.75H5.625a1.875 1.875 0 01-1.875-1.875v-6.198a2.29 2.29 0 00.091-.086L12 5.43z"></path></svg>`, {
                interactive: true,
                permanent: true,
                direction: 'center',
                className: "text-sm rounded-full border bg-[#1484FF] text-white font-bold"
            });
        }

        $(".leaflet-marker-shadow").remove();
        $(".leaflet-marker-icon").remove();
        $(".leaflet-popup").remove();
    });
</script>
<?php /**PATH C:\XBoost\imoveis\resources\views/components/map-view.blade.php ENDPATH**/ ?>