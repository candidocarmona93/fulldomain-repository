<div class="bg-[#F7F7F7] py-[13px] border-t-2 border-t-[#DDD] sm:mb-0 mb-[54px] loading-show">
    <div class="container mx-auto px-6">
        <div class="grid grid-cols-12 sm:my-16 my-8 sm:space-y-0 space-y-4">
            <div class="md:col-start-2 md:col-end-5 sm:col-start-2 sm:col-end-4 col-span-12 sm:space-y-4 space-y-2">
                <h3 class="font-semibold text-lg">Apoio</h3>
                <div class="flex flex-col gap-2">
                    <a href="https://casacoimbramaputo.com/centro-de-apoio" class="text-sm text-[#222] hover:text-[#808080]">Centro de Apoio</a>
                </div>
            </div>
            <div class="md:col-start-6 md:col-end-8 sm:col-start-5 sm:col-end-7 col-span-12 sm:space-y-4 space-y-2">
                <h3 class="font-semibold text-lg">Casa Coimbra Maputo</h3>
                <div class="flex flex-col gap-2">
                    <a href="https://casacoimbramaputo.com/host" class="text-sm text-[#222] hover:text-[#808080]">Minha casa</a>
                    <a href="https://casacoimbramaputo.com/eu-sou-o-dono" class="text-sm text-[#222] hover:text-[#808080]">Eu Sou O Dono</a>
                    <a href="https://casacoimbramaputo.com/parceiros" class="text-sm text-[#222] hover:text-[#808080]">Parceiros</a>
                </div>
            </div>
            <div class="md:col-start-10 md:col-end-12 sm:col-start-8 sm:col-end-12 col-span-12 sm:space-y-4 space-y-2">
                <h3 class="font-semibold text-lg">Contacto</h3>
                <div class="flex flex-col gap-2">
                    <span class="text-sm">
                        <a href="tel:+258 84 016 9593">
                            +258 84 016 9593
                        </a>
                    </span>
                    <span class="text-sm">
                        <a href="mailto:info@casacoimbramaputo.com">
                            info@casacoimbramaputo.com
                        </a>
                    </span>
                    <span class="text-sm">Praceta de Diu, Av. Maguiguana, N°26 R/C, Maputo, Moçambique</span>
                </div>
            </div>
        </div>
        <hr class="w-full h-1 bg-[#DDD] border-0 rounded">
        <div class="grid grid-cols-12 pt-[13px] text-[#222]">
            <div class="sm:col-span-9 col-span-12 flex gap-[10px] sm:flex-row flex-col">
                <span><script>document.write(new Date().getFullYear())</script> &copy; Casa Coimbra Maputo</span>
                <a href="#" class="hover:text-[#808080]">Termos</a>
                <a href="#" class="hover:text-[#808080]">Mapa do site</a>
            </div>
            <div class="sm:col-span-3 col-span-12 flex flex-col sm:flex-row sm:space-x-6 sm:justify-end sm:space-y-0 space-y-3 mt-3 sm:mt-0">
                <div class="flex items-center gap-1 sm:hover:bg-[#e7e7e7] rounded-lg sm:px-2 cursor-pointer">
                    <?php if (isset($component)) { $__componentOriginal0bf795148d16d030322e8bad8c3675be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0bf795148d16d030322e8bad8c3675be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.globe-alt-icon','data' => ['class' => 'h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.globe-alt-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0bf795148d16d030322e8bad8c3675be)): ?>
<?php $attributes = $__attributesOriginal0bf795148d16d030322e8bad8c3675be; ?>
<?php unset($__attributesOriginal0bf795148d16d030322e8bad8c3675be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0bf795148d16d030322e8bad8c3675be)): ?>
<?php $component = $__componentOriginal0bf795148d16d030322e8bad8c3675be; ?>
<?php unset($__componentOriginal0bf795148d16d030322e8bad8c3675be); ?>
<?php endif; ?>
                    <span class="md:block sm:hidden block">Português</span>
                    <span class="md:hidden sm:block hidden">PT</span>
                </div>
                <div class="flex gap-2">
                    <a class="text-[#222] hover:text-[#808080]" href="https://wa.me/+258840169593" target="_blank">
                        <?php if (isset($component)) { $__componentOriginal7e508e0ae2c71fd5977618c08090897c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e508e0ae2c71fd5977618c08090897c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.whatsapp-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.whatsapp-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e508e0ae2c71fd5977618c08090897c)): ?>
<?php $attributes = $__attributesOriginal7e508e0ae2c71fd5977618c08090897c; ?>
<?php unset($__attributesOriginal7e508e0ae2c71fd5977618c08090897c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e508e0ae2c71fd5977618c08090897c)): ?>
<?php $component = $__componentOriginal7e508e0ae2c71fd5977618c08090897c; ?>
<?php unset($__componentOriginal7e508e0ae2c71fd5977618c08090897c); ?>
<?php endif; ?>
                    </a>
                    <a class="text-[#222] hover:text-[#808080]" href="https://www.facebook.com/CasacoimbraMaputo/about/" target="_blank">
                        <?php if (isset($component)) { $__componentOriginaled0ff15acefec42c366983359a4c9468 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled0ff15acefec42c366983359a4c9468 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.facebook-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.facebook-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled0ff15acefec42c366983359a4c9468)): ?>
<?php $attributes = $__attributesOriginaled0ff15acefec42c366983359a4c9468; ?>
<?php unset($__attributesOriginaled0ff15acefec42c366983359a4c9468); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled0ff15acefec42c366983359a4c9468)): ?>
<?php $component = $__componentOriginaled0ff15acefec42c366983359a4c9468; ?>
<?php unset($__componentOriginaled0ff15acefec42c366983359a4c9468); ?>
<?php endif; ?>
                    </a>
                    <a class="text-[#222] hover:text-[#808080]" href="https://www.instagram.com/casa_coimbra_maputo/" target="_blank">
                        <?php if (isset($component)) { $__componentOriginal3fe17ef1b7f85adbfde3952241273e49 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fe17ef1b7f85adbfde3952241273e49 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.instagram-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.instagram-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fe17ef1b7f85adbfde3952241273e49)): ?>
<?php $attributes = $__attributesOriginal3fe17ef1b7f85adbfde3952241273e49; ?>
<?php unset($__attributesOriginal3fe17ef1b7f85adbfde3952241273e49); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fe17ef1b7f85adbfde3952241273e49)): ?>
<?php $component = $__componentOriginal3fe17ef1b7f85adbfde3952241273e49; ?>
<?php unset($__componentOriginal3fe17ef1b7f85adbfde3952241273e49); ?>
<?php endif; ?>
                    </a>
                    <a class="text-[#222] hover:text-[#808080]" href="https://www.youtube.com/@pedrocoimbrarealestateguru5726" target="_blank">
                        <?php if (isset($component)) { $__componentOriginal4264b316fb7dd2921d622fbdacbeb877 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4264b316fb7dd2921d622fbdacbeb877 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.youtube','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.youtube'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4264b316fb7dd2921d622fbdacbeb877)): ?>
<?php $attributes = $__attributesOriginal4264b316fb7dd2921d622fbdacbeb877; ?>
<?php unset($__attributesOriginal4264b316fb7dd2921d622fbdacbeb877); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4264b316fb7dd2921d622fbdacbeb877)): ?>
<?php $component = $__componentOriginal4264b316fb7dd2921d622fbdacbeb877; ?>
<?php unset($__componentOriginal4264b316fb7dd2921d622fbdacbeb877); ?>
<?php endif; ?>
                    </a>
                    <a class="text-[#222] hover:text-[#808080]" href="https://mz.linkedin.com/in/casa-coimbra-real-estate-maputo-5706601a7" target="_blank">
                        <?php if (isset($component)) { $__componentOriginal219d77e68609839e07e0d8c352b4a26b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal219d77e68609839e07e0d8c352b4a26b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.linkedin-in-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.linkedin-in-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal219d77e68609839e07e0d8c352b4a26b)): ?>
<?php $attributes = $__attributesOriginal219d77e68609839e07e0d8c352b4a26b; ?>
<?php unset($__attributesOriginal219d77e68609839e07e0d8c352b4a26b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal219d77e68609839e07e0d8c352b4a26b)): ?>
<?php $component = $__componentOriginal219d77e68609839e07e0d8c352b4a26b; ?>
<?php unset($__componentOriginal219d77e68609839e07e0d8c352b4a26b); ?>
<?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/casacoim/imoveis.casacoimbramaputo.com/resources/views/components/footer.blade.php ENDPATH**/ ?>