<svg width="24" height="24" viewBox="0 0 24 24" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" :fill="fill">
    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
    <g id="SVGRepo_iconCarrier">
        <rect style="fill:none;stroke:#0F172A;stroke-miterlimit:10;stroke-width:1.056;" x="5.32" y="13.91" width="13.36" height="4.77"></rect>
        <rect style="fill:none;stroke:#0F172A;stroke-miterlimit:10;stroke-width:1.056;" x="5.32" y="13.91" width="13.36" height="4.77"></rect>
        <path style="fill:none;stroke:#0F172A;stroke-miterlimit:10;stroke-width:1.056;" d="M20.59,11h0A1.91,1.91,0,0,1,22.5,13v5.73a0,0,0,0,1,0,0H18.68a0,0,0,0,1,0,0V13A1.91,1.91,0,0,1,20.59,11Z"></path>
        <path style="fill:none;stroke:#0F172A;stroke-miterlimit:10;stroke-width:1.056;" d="M3.41,11h0A1.91,1.91,0,0,1,5.32,13v5.73a0,0,0,0,1,0,0H1.5a0,0,0,0,1,0,0V13A1.91,1.91,0,0,1,3.41,11Z"></path>
        <path style="fill:none;stroke:#0F172A;stroke-miterlimit:10;stroke-width:1.056;" d="M4.36,11.05V8.18A2.87,2.87,0,0,1,7.23,5.32h9.54a2.87,2.87,0,0,1,2.87,2.86v2.87"></path>
        <line style="fill:none;stroke:#0F172A;stroke-miterlimit:10;stroke-width:1.056;" x1="8.18" y1="10.09" x2="10.09" y2="10.09"></line>
        <line style="fill:none;stroke:#0F172A;stroke-miterlimit:10;stroke-width:1.056;" x1="13.91" y1="10.09" x2="15.82" y2="10.09"></line>
    </g>
</svg>
<?php /**PATH /home/casacoim/imoveis.casacoimbramaputo.com/resources/views/components/icons/living-room-icon.blade.php ENDPATH**/ ?>