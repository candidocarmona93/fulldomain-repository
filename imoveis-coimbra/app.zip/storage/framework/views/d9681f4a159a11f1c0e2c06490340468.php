<section class="sticky top-[4rem] z-10">
    <div class="md:block hidden bg-white border-b-2 border-[#CACACA] mt-10">
        <div class="grid grid-cols-12">
            <div class="col-start-2 col-end-10">
                <div class="nav-sticker space-x-5 font-medium flex items-center">
                    <p class="fotos py-4 text-[#b3b3b3] active cursor-pointer hover:text-[#222]">
                        <a href="#fotos">Fotos</a>
                    </p>
                    <p class="comodidades py-4 text-[#b3b3b3] cursor-pointer hover:text-[#222]">
                        <a href="#comodidades">Comodidades</a>
                    </p>
                    <p class="comentarios py-4 text-[#b3b3b3] cursor-pointer hover:text-[#222]">
                        <a href="#comentarios">Comentários</a>
                    </p>
                    <p class="localizacao py-4 text-[#b3b3b3] cursor-pointer hover:text-[#222]">
                        <a href="#localizacao">Localização</a>
                    </p>
                </div>
            </div>
            <div class="col-start-11 col-end-12">
                <div class="flex gap-5 py-3 font-medium">
                    <div class="flex items-center gap-2 border text-[#1484FF] border-[#1484FF] hover:bg-[#1484FF] hover:text-white transition-all ease-in-out rounded-lg px-2 py-1 cursor-pointer" data-ripple-light="true" data-dialog-target="share">
                        <?php if (isset($component)) { $__componentOriginal4266b158291c73a5dc6e88b58abfc4e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4266b158291c73a5dc6e88b58abfc4e6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.share-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.share-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4266b158291c73a5dc6e88b58abfc4e6)): ?>
<?php $attributes = $__attributesOriginal4266b158291c73a5dc6e88b58abfc4e6; ?>
<?php unset($__attributesOriginal4266b158291c73a5dc6e88b58abfc4e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4266b158291c73a5dc6e88b58abfc4e6)): ?>
<?php $component = $__componentOriginal4266b158291c73a5dc6e88b58abfc4e6; ?>
<?php unset($__componentOriginal4266b158291c73a5dc6e88b58abfc4e6); ?>
<?php endif; ?>
                        <span class="text-base">Partilhar</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php if (isset($component)) { $__componentOriginal2e26927cdfb99f30fef35f337c57a089 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e26927cdfb99f30fef35f337c57a089 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.default','data' => ['name' => 'share','maxWidth' => 'max-w-xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'share','maxWidth' => 'max-w-xl']); ?>
     <?php $__env->slot('body', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginal7a0b95220659ba480c4a04bff5481890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a0b95220659ba480c4a04bff5481890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.share','data' => ['title' => $title,'url' => $url,'picture' => $image]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.share'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($url),'picture' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($image)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a0b95220659ba480c4a04bff5481890)): ?>
<?php $attributes = $__attributesOriginal7a0b95220659ba480c4a04bff5481890; ?>
<?php unset($__attributesOriginal7a0b95220659ba480c4a04bff5481890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a0b95220659ba480c4a04bff5481890)): ?>
<?php $component = $__componentOriginal7a0b95220659ba480c4a04bff5481890; ?>
<?php unset($__componentOriginal7a0b95220659ba480c4a04bff5481890); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e26927cdfb99f30fef35f337c57a089)): ?>
<?php $attributes = $__attributesOriginal2e26927cdfb99f30fef35f337c57a089; ?>
<?php unset($__attributesOriginal2e26927cdfb99f30fef35f337c57a089); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e26927cdfb99f30fef35f337c57a089)): ?>
<?php $component = $__componentOriginal2e26927cdfb99f30fef35f337c57a089; ?>
<?php unset($__componentOriginal2e26927cdfb99f30fef35f337c57a089); ?>
<?php endif; ?>
<style>
    .active {
        color: #222!important;
    }
    html {
        scroll-behavior: smooth;
    }
</style>
<script>
    const sections = document.querySelectorAll("section");
    const navA = document.querySelectorAll(".nav-sticker p");

    window.onscroll = () => {
        var current = "";

        sections.forEach((section) => {
            const sectionTop = section.offsetTop;
            if (pageYOffset >= sectionTop - 120) {
                current = section.getAttribute("id");
            }
        });

        navA.forEach((p) => {
            p.classList.remove("active");
            if (p.classList.contains(current)) {
                p.classList.add("active");
            }
        });
    };
</script>
<?php /**PATH /home/casacoim/imoveis.casacoimbramaputo.com/resources/views/components/navbar-sticker.blade.php ENDPATH**/ ?>