<section id="comentarios">
    <div class="flex gap-1 items-center">
        <?php if (isset($component)) { $__componentOriginaleb5ce9dd91dc7f90ee391860b75880fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb5ce9dd91dc7f90ee391860b75880fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.star-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.star-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb5ce9dd91dc7f90ee391860b75880fc)): ?>
<?php $attributes = $__attributesOriginaleb5ce9dd91dc7f90ee391860b75880fc; ?>
<?php unset($__attributesOriginaleb5ce9dd91dc7f90ee391860b75880fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb5ce9dd91dc7f90ee391860b75880fc)): ?>
<?php $component = $__componentOriginaleb5ce9dd91dc7f90ee391860b75880fc; ?>
<?php unset($__componentOriginaleb5ce9dd91dc7f90ee391860b75880fc); ?>
<?php endif; ?>
        <span class="text-2xl font-medium text-[#222]"><?php echo e($comments); ?> comentários</span>
    </div>
    <?php if($comments > 0): ?>
    <div class="grid grid-cols-2 my-4 space-y-6">
        <div class="col-span-1" v-for="comment in comments">
            <h4 class="font-bold text-[#222]"><?php echo e($comment->summary); ?></h4>
            <div class="space-y-2 mt-3">
                <p><?php echo e(comment.analysis); ?></p>
                <p class="text-[#808080]"><?php echo e($comment->nickname); ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <h3 class="text-lg text-center py-3 mt-3 bg-slate-100/50 text-slate-500 font-medium rounded-lg" v-else>
        Sem comentários
    </h3>
</section>
<?php /**PATH D:\XBoost\imoveis\resources\views/components/comment.blade.php ENDPATH**/ ?>