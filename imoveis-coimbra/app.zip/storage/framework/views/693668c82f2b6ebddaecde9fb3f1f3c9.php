<nav class="bg-white border-b-2 border-gray-200 sticky top-0 z-20 loading-show">
    <div class="container mx-auto px-2 sm:px-6">
        <div class="relative flex h-16 gap-3 items-center justify-between">
            <div class="sm:flex sm:flex-1 flex-auto w-full items-center sm:justify-start lg:gap-2">
                <a href="https://casacoimbramaputo.com/" class="h-10 w-72 sm:block hidden bg-cover bg-center" style="background-image: url(https://workspace.casacoimbramaputo.com/img/website/base/logo-horizontal.png)"></a>
                <div class="sm:ml-6 sm:block xl:w-full lg:w-2/3 w-[inherit]">
                    <div class="sm:max-w-sm max-w-full mx-auto">
                        <label for="default-search" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
                        <div class="relative">
                            <input type="search" class="w-full py-2 px-4 pr-10 text-sm text-gray-900 border border-gray-300 rounded-full bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Em qualquer lugar" data-ripple-light="true" data-dialog-target="navbar">
                            <button type="button" class="text-white absolute right-[3px] bottom-[3px] bg-blue-600 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-full text-sm p-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                <svg
                                    xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" aria-hidden="true"
                                    class="text-white dark:text-gray-400" style="width: 1rem; height:1rem;"
                                >
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z">
                                    </path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="lg:flex shrink lg:w-1/2 hidden space-x-3">
                    <a href="https://casacoimbramaputo.com/host"
                        class="px-3 py-2 rounded-lg text-sm border border-slate-800 easy-in-out duration-700 bg-[#F9F9F9] hover:bg-[#e7e7e7] text-[#484848]"
                        target="" style="border-radius: 25px !important;">
                        Minha casa
                    </a>
                    <a href="https://casacoimbramaputo.com/investimentos"
                        class="py-2 rounded-lg text-sm border border-slate-800 easy-in-out duration-700 bg-[#F9F9F9] hover:bg-[#e7e7e7] text-[#484848] px-4 font-semibold"
                        target="" style="border-radius: 25px !important;">
                        Investimentos
                    </a>
                    <div class="flex items-center easy-in-out duration-700 gap-1 sm:hover:bg-[#e7e7e7] rounded-full sm:px-2 cursor-pointer sr-only">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418">
                            </path>
                        </svg>
                        <span class="text-sm">PT</span>
                    </div>
                </div>
            </div>
            <div class="lg:hidden sm:flex hidden space-x-3 ms-3">
                <a href="https://casacoimbramaputo.com/host" class="rounded-full border border-slate-800 bg-[#F9F9F9] hover:bg-[#e7e7e7] focus:ring-4 focus:outline-none focus:ring-[#f1f1f1] dark:bg-[#f1f1f1] dark:hover:bg-[#f1f1f1] dark:focus:ring-[#f1f1f1] text-slate-800 p-2" target="">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"></path>
                    </svg>
                </a>
                <a href="https://casacoimbramaputo.com/investimentos" class="rounded-full border border-slate-800 bg-[#F9F9F9] hover:bg-[#e7e7e7] focus:ring-4 focus:outline-none focus:ring-[#f1f1f1] dark:bg-[#f1f1f1] dark:hover:bg-[#f1f1f1] dark:focus:ring-[#f1f1f1] text-slate-800 py-2 px-4" target="">
                    <span class="font-bold">Investimentos</span>
                </a>
            </div>
        </div>
    </div>
</nav>
<navbottom class="sm:hidden block fixed bottom-0 bg-white border-t-2 border-gray-200 z-20 w-full">
    <div class="container mx-auto px-7">
        <div class="grid grid-cols-4 gap-4 text-sm">
            <a href="https://casacoimbramaputo.com/" class="flex flex-col items-center text-center my-2 text-slate-800">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" style="width:1.75rem; height:1.75rem;">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21m0 0h4.5V3.545M12.75 21h7.5V10.75M2.25 21h1.5m18 0h-18M2.25 9l4.5-1.636M18.75 3l-1.5.545m0 6.205l3 1m1.5.5l-1.5-.5M6.75 7.364V3h-3v18m3-13.636l10.5-3.819">
                    </path>
                </svg><span class="text-xs">Imóveis</span></a>
                <a href="https://casacoimbramaputo.com/host" class="flex flex-col items-center text-center my-2 text-slate-800">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25">
                    </path>
                </svg><span class="text-xs">Minha casa</span></a>
                <a href="https://casacoimbramaputo.com/investimentos" class="flex flex-col items-center text-center my-2 text-slate-800">
                    <svg class="svg-inline--fa fa-handshake" style="width:1.5rem; height:1.5rem;" aria-hidden="true" focusable="false" data-prefix="far" data-icon="handshake" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
                    <path class="" fill="currentColor"
                        d="M272.2 64.6l-51.1 51.1c-15.3 4.2-29.5 11.9-41.5 22.5L153 161.9C142.8 171 129.5 176 115.8 176H96V304c20.4 .6 39.8 8.9 54.3 23.4l35.6 35.6 7 7 0 0L219.9 397c6.2 6.2 16.4 6.2 22.6 0c1.7-1.7 3-3.7 3.7-5.8c2.8-7.7 9.3-13.5 17.3-15.3s16.4 .6 22.2 6.5L296.5 393c11.6 11.6 30.4 11.6 41.9 0c5.4-5.4 8.3-12.3 8.6-19.4c.4-8.8 5.6-16.6 13.6-20.4s17.3-3 24.4 2.1c9.4 6.7 22.5 5.8 30.9-2.6c9.4-9.4 9.4-24.6 0-33.9L340.1 243l-35.8 33c-27.3 25.2-69.2 25.6-97 .9c-31.7-28.2-32.4-77.4-1.6-106.5l70.1-66.2C303.2 78.4 339.4 64 377.1 64c36.1 0 71 13.3 97.9 37.2L505.1 128H544h40 40c8.8 0 16 7.2 16 16V352c0 17.7-14.3 32-32 32H576c-11.8 0-22.2-6.4-27.7-16H463.4c-3.4 6.7-7.9 13.1-13.5 18.7c-17.1 17.1-40.8 23.8-63 20.1c-3.6 7.3-8.5 14.1-14.6 20.2c-27.3 27.3-70 30-100.4 8.1c-25.1 20.8-62.5 19.5-86-4.1L159 404l-7-7-35.6-35.6c-5.5-5.5-12.7-8.7-20.4-9.3C96 369.7 81.6 384 64 384H32c-17.7 0-32-14.3-32-32V144c0-8.8 7.2-16 16-16H56 96h19.8c2 0 3.9-.7 5.3-2l26.5-23.6C175.5 77.7 211.4 64 248.7 64H259c4.4 0 8.9 .2 13.2 .6zM544 320V176H496c-5.9 0-11.6-2.2-15.9-6.1l-36.9-32.8c-18.2-16.2-41.7-25.1-66.1-25.1c-25.4 0-49.8 9.7-68.3 27.1l-70.1 66.2c-10.3 9.8-10.1 26.3 .5 35.7c9.3 8.3 23.4 8.1 32.5-.3l71.9-66.4c9.7-9 24.9-8.4 33.9 1.4s8.4 24.9-1.4 33.9l-.8 .8 74.4 74.4c10 10 16.5 22.3 19.4 35.1H544zM64 336a16 16 0 1 0 -32 0 16 16 0 1 0 32 0zm528 16a16 16 0 1 0 0-32 16 16 0 1 0 0 32z">
                    </path>
                </svg>
                <span class="text-xs">Investimentos</span>
            </a>
                <a href="https://casacoimbramaputo.com/centro-de-apoio" class="flex flex-col items-center text-center my-2 text-slate-800">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" style="width:1.75rem; height:1.75rem;">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M16.712 4.33a9.027 9.027 0 011.652 1.306c.51.51.944 1.064 1.306 1.652M16.712 4.33l-3.448 4.138m3.448-4.138a9.014 9.014 0 00-9.424 0M19.67 7.288l-4.138 3.448m4.138-3.448a9.014 9.014 0 010 9.424m-4.138-5.976a3.736 3.736 0 00-.88-1.388 3.737 3.737 0 00-1.388-.88m2.268 2.268a3.765 3.765 0 010 2.528m-2.268-4.796a3.765 3.765 0 00-2.528 0m4.796 4.796c-.181.506-.475.982-.88 1.388a3.736 3.736 0 01-1.388.88m2.268-2.268l4.138 3.448m0 0a9.027 9.027 0 01-1.306 1.652c-.51.51-1.064.944-1.652 1.306m0 0l-3.448-4.138m3.448 4.138a9.014 9.014 0 01-9.424 0m5.976-4.138a3.765 3.765 0 01-2.528 0m0 0a3.736 3.736 0 01-1.388-.88 3.737 3.737 0 01-.88-1.388m2.268 2.268L7.288 19.67m0 0a9.024 9.024 0 01-1.652-1.306 9.027 9.027 0 01-1.306-1.652m0 0l4.138-3.448M4.33 16.712a9.014 9.014 0 010-9.424m4.138 5.976a3.765 3.765 0 010-2.528m0 0c.181-.506.475-.982.88-1.388a3.736 3.736 0 011.388-.88m-2.268 2.268L4.33 7.288m6.406 1.18L7.288 4.33m0 0a9.024 9.024 0 00-1.652 1.306A9.025 9.025 0 004.33 7.288">
                    </path>
                </svg>
                <span class="text-xs">Ajuda</span>
            </a>
        </div>
    </div>
</navbottom>

<?php if (isset($component)) { $__componentOriginal2e26927cdfb99f30fef35f337c57a089 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e26927cdfb99f30fef35f337c57a089 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.default','data' => ['name' => 'navbar','maxWidth' => 'lg:max-w-5xl max-w-2xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'navbar','maxWidth' => 'lg:max-w-5xl max-w-2xl']); ?>
     <?php $__env->slot('body', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginaldb7e211f66da07602cac3fd2bcda372c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb7e211f66da07602cac3fd2bcda372c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb7e211f66da07602cac3fd2bcda372c)): ?>
<?php $attributes = $__attributesOriginaldb7e211f66da07602cac3fd2bcda372c; ?>
<?php unset($__attributesOriginaldb7e211f66da07602cac3fd2bcda372c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb7e211f66da07602cac3fd2bcda372c)): ?>
<?php $component = $__componentOriginaldb7e211f66da07602cac3fd2bcda372c; ?>
<?php unset($__componentOriginaldb7e211f66da07602cac3fd2bcda372c); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e26927cdfb99f30fef35f337c57a089)): ?>
<?php $attributes = $__attributesOriginal2e26927cdfb99f30fef35f337c57a089; ?>
<?php unset($__attributesOriginal2e26927cdfb99f30fef35f337c57a089); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e26927cdfb99f30fef35f337c57a089)): ?>
<?php $component = $__componentOriginal2e26927cdfb99f30fef35f337c57a089; ?>
<?php unset($__componentOriginal2e26927cdfb99f30fef35f337c57a089); ?>
<?php endif; ?>
<style>
    .btn-pulse {
        box-shadow: 0 0 0 0 rgba(20, 134, 255, 0.7);
        -webkit-animation: pulsing 1.25s infinite cubic-bezier(0.46, 0, 0, 1);
        -moz-animation: pulsing 1.25s infinite cubic-bezier(0.46, 0, 0, 1);
        -ms-animation: pulsing 1.25s infinite cubic-bezier(0.46, 0, 0, 1);
        animation: pulsing 1.25s infinite cubic-bezier(0.46, 0, 0, 1);
        transition: all 300ms ease-in-out;
    }
    .btn-pulse:hover {
        -webkit-animation: none;
        -moz-animation: none;
        -ms-animation: none;
        animation: none;
        color: #ffffff;
    }

    /* Animation */
    @-webkit-keyframes pulsing {
        to {
            box-shadow: 0 0 0 20px rgba(232, 76, 61, 0);
        }
    }

    @-moz-keyframes pulsing {
        to {
            box-shadow: 0 0 0 20px rgba(232, 76, 61, 0);
        }
    }

    @-ms-keyframes pulsing {
        to {
            box-shadow: 0 0 0 20px rgba(232, 76, 61, 0);
        }
    }

    @keyframes pulsing {
        to {
            box-shadow: 0 0 0 20px rgba(232, 76, 61, 0);
        }
    }
</style>
<?php /**PATH D:\XBoost\imoveis\resources\views/components/navbar.blade.php ENDPATH**/ ?>