<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <?php echo SEOMeta::generate(); ?>

        <?php echo OpenGraph::generate(); ?>

        <?php echo Twitter::generate(); ?>

        <?php echo JsonLd::generate(); ?>

        <link rel="stylesheet" href="<?php echo e(asset('./plugins/jquery.datetimepicker/jquery.datetimepicker.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('./css/app.css')); ?>">
        <!-- from cdn -->
        <script src="https://unpkg.com/@material-tailwind/html@latest/scripts/dialog.js"></script>
        <script src="<?php echo e(asset('./js/app.js')); ?>"></script>
    </head>
    <body>
        <slot />
        <!--Start of Tawk.to Script-->
		<script type="text/javascript">
			var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
			(function(){
				var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
				s1.async=true;
				s1.src='https://embed.tawk.to/64be22fc94cf5d49dc66013d/1h63bhbem';
				s1.charset='UTF-8';
				s1.setAttribute('crossorigin','*');
				s0.parentNode.insertBefore(s1,s0);
			})();

			Tawk_API.customStyle = {
				visibility : {
					mobile : {
						position : 'br',
						xOffset : '20px',
						yOffset : '73px'
					},
					bubble : {
						rotate : '0deg',
						xOffset : -20,
						yOffset : 0
					}
				}
			};
            $(function() {
                $('body').scrollTop(0);
            });
		</script>
		<!--End of Tawk.to Script-->
    </body>
</html>
<?php /**PATH C:\XBoost\imoveis\resources\views/layouts/app.blade.php ENDPATH**/ ?>