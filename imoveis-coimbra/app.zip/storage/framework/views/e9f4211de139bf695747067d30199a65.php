<div>
    <div class="swiper mySwiper">
        <div class="swiper-wrapper">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
                <img class="object-cover h-80 w-full" src="https://workspace.casacoimbramaputo.com/uploads/immobiles/<?php echo e($code); ?>/<?php echo e($item->picture); ?>" />
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>

        <div class="swiper-scrollbar"></div>

        <button type="button" class="flex gap-2 items-center bg-white border-2 border-[#222] text-[#222] text-sm font-semibold rounded-lg px-[13px] py-[7px] hover:text-slate-700 absolute right-[56px] bottom-5 z-10">
            <?php if (isset($component)) { $__componentOriginal5f5342822db69ab804b7af54df09da44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5f5342822db69ab804b7af54df09da44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.squares-2-x-2-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.squares-2-x-2-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5f5342822db69ab804b7af54df09da44)): ?>
<?php $attributes = $__attributesOriginal5f5342822db69ab804b7af54df09da44; ?>
<?php unset($__attributesOriginal5f5342822db69ab804b7af54df09da44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f5342822db69ab804b7af54df09da44)): ?>
<?php $component = $__componentOriginal5f5342822db69ab804b7af54df09da44; ?>
<?php unset($__componentOriginal5f5342822db69ab804b7af54df09da44); ?>
<?php endif; ?>
            Ver todas images
        </button>
    </div>
</div>
<link rel="stylesheet" href="<?php echo e(asset('./plugins/swiper/css/swiper-bundle.min.css')); ?>">
<script src="<?php echo e(asset('./plugins/jquery/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('./plugins/swiper/js/swiper-bundle.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        const sw = new Swiper('.mySwiper', {
            breakpoints: {
                320: {
                    slidesPerView: 1,
                    spaceBetween: 3
                },
                640: {
                    slidesPerView: 2,
                    spaceBetween: 4
                },
                1280: {
                    slidesPerView: 3,
                    spaceBetween: 5
                }
            },
            freeMode: true,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            scrollbar: {
                el: '.swiper-scrollbar',
                draggable: true,
                dragSize: 200,
            },
        });
    })
</script>
<?php /**PATH /home/casacoim/imoveis.casacoimbramaputo.com/resources/views/components/gallery.blade.php ENDPATH**/ ?>