<div>
    <div class="flex items-center space-x-2 mb-4 overflow-y-auto">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
            <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"></path>
        </svg>
        <input type="search" class="w-full py-2 px-4 text-sm text-gray-900 border-none bg-white focus:ring-0 focus:border-none focus-visible:ring-0 focus-visible:outline-none" placeholder="Pesquisa em qualquer lugar" id="pesquisar" autofocus="">
    </div>
    <div id="results">
        <ul>
            <li class="font-medium py-2 text-[#666666] border-t-[1px]">
                Nenhum imóvel encontrado
            </li>
        </ul>
    </div>
</div>
<script src="<?php echo e(asset('./plugins/jquery/jquery-3.3.1.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        function search(e) {
            var htmlView = '<ul> <li class="font-medium py-2 text-[#666666] border-t-[1px]" id="total"> Mostrando 0 de imoveis como resultados </li> </ul> <ul class="overflow-y-auto max-h-80">'
            $.ajax({
                url: 'https://workspace.casacoimbramaputo.com/api/search-immobile',
                method: 'POST',
                data: {
                    "text": e,
                    "limit": 15
                },
                success: function(response) {
                    if(response.length > 0) {
                        $.each(response, function(index, value){
                            htmlView += `<ul class="overflow-y-auto max-h-80">
                                <li class="py-2 border-t-[1px] hover:bg-gray-100 cursor-pointer">
                                    <div class="flex items-center gap-4">
                                        <img class="object-cover rounded-lg w-12" src="https://workspace.casacoimbramaputo.com/uploads/immobiles/${ value.code }/${ value.picture }" alt="${ value.title }">
                                        <a class="no-underline" href="https://imoveis.casacoimbramaputo.com/${ value.slug }" target="_blank">${ value.title }</a>
                                    </div>
                                </li>
                            </ul>`
                        });

                        htmlView += '</u>';
                        $("#results").html(htmlView);
                        $("#total").html(`Mostrando ${ response.length } de imoveis como resultados`)
                    } else {
                        $("#results").html(`
                            <ul>
                                <li class="font-medium py-2 text-[#666666] border-t-[1px]">
                                    Nenhum imóvel encontrado
                                </li>
                            </ul>
                        `);
                    }
                },
            });
        }

        $("#pesquisar").keyup(function() {
            let text = $(this).val()
            if(text === '') {
                $("#results").html(`
                    <ul>
                        <li class="font-medium py-2 text-[#666666] border-t-[1px]">
                            Nenhum imóvel encontrado
                        </li>
                    </ul>
                `);
            } else {
                search(text)
            }
        });
    });
</script>
<?php /**PATH /home/casacoim/imoveis.casacoimbramaputo.com/resources/views/components/modal/search.blade.php ENDPATH**/ ?>