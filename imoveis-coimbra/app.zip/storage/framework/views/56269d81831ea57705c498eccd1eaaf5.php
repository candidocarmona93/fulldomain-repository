<section id="comodidades">
    <h3 class="font-medium text-2xl mb-2 text-[#222]">Comodidades</h3>
    <div class="grid xl:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-4">
        <?php if($car == 1): ?>
        <div class="flex items-center gap-2" >
            <?php if (isset($component)) { $__componentOriginal0176d90daf58a9da9b65174c590b9cac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0176d90daf58a9da9b65174c590b9cac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.car-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.car-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0176d90daf58a9da9b65174c590b9cac)): ?>
<?php $attributes = $__attributesOriginal0176d90daf58a9da9b65174c590b9cac; ?>
<?php unset($__attributesOriginal0176d90daf58a9da9b65174c590b9cac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0176d90daf58a9da9b65174c590b9cac)): ?>
<?php $component = $__componentOriginal0176d90daf58a9da9b65174c590b9cac; ?>
<?php unset($__componentOriginal0176d90daf58a9da9b65174c590b9cac); ?>
<?php endif; ?>
            <span class="text-base">Garagem de carro</span>
        </div>
        <?php endif; ?>
        <?php if($pool == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal2d66b68943c32fa3e918360b4e838b56 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d66b68943c32fa3e918360b4e838b56 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.pool-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.pool-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d66b68943c32fa3e918360b4e838b56)): ?>
<?php $attributes = $__attributesOriginal2d66b68943c32fa3e918360b4e838b56; ?>
<?php unset($__attributesOriginal2d66b68943c32fa3e918360b4e838b56); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d66b68943c32fa3e918360b4e838b56)): ?>
<?php $component = $__componentOriginal2d66b68943c32fa3e918360b4e838b56; ?>
<?php unset($__componentOriginal2d66b68943c32fa3e918360b4e838b56); ?>
<?php endif; ?>
            <span class="text-base">Piscina</span>
        </div>
        <?php endif; ?>
        <?php if($cave == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal8f79e904adaa652390d7c28ecb4ac591 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f79e904adaa652390d7c28ecb4ac591 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.basement-icon','data' => ['class' => 'h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.basement-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f79e904adaa652390d7c28ecb4ac591)): ?>
<?php $attributes = $__attributesOriginal8f79e904adaa652390d7c28ecb4ac591; ?>
<?php unset($__attributesOriginal8f79e904adaa652390d7c28ecb4ac591); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f79e904adaa652390d7c28ecb4ac591)): ?>
<?php $component = $__componentOriginal8f79e904adaa652390d7c28ecb4ac591; ?>
<?php unset($__componentOriginal8f79e904adaa652390d7c28ecb4ac591); ?>
<?php endif; ?>
            <span class="text-base">Cave</span>
        </div>
        <?php endif; ?>
        <?php if($wifi == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal2b1b136b457c897bb7b849dd74947ec2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b1b136b457c897bb7b849dd74947ec2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.wifi-icon','data' => ['class' => 'h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.wifi-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b1b136b457c897bb7b849dd74947ec2)): ?>
<?php $attributes = $__attributesOriginal2b1b136b457c897bb7b849dd74947ec2; ?>
<?php unset($__attributesOriginal2b1b136b457c897bb7b849dd74947ec2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b1b136b457c897bb7b849dd74947ec2)): ?>
<?php $component = $__componentOriginal2b1b136b457c897bb7b849dd74947ec2; ?>
<?php unset($__componentOriginal2b1b136b457c897bb7b849dd74947ec2); ?>
<?php endif; ?>
            <span class="text-base">Wi-Fi</span>
        </div>
        <?php endif; ?>
        <?php if($park == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal7354b38120182aad02cc28284ef7c140 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7354b38120182aad02cc28284ef7c140 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.park-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.park-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7354b38120182aad02cc28284ef7c140)): ?>
<?php $attributes = $__attributesOriginal7354b38120182aad02cc28284ef7c140; ?>
<?php unset($__attributesOriginal7354b38120182aad02cc28284ef7c140); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7354b38120182aad02cc28284ef7c140)): ?>
<?php $component = $__componentOriginal7354b38120182aad02cc28284ef7c140; ?>
<?php unset($__componentOriginal7354b38120182aad02cc28284ef7c140); ?>
<?php endif; ?>
            <span class="text-base">Parque</span>
        </div>
        <?php endif; ?>
        <?php if($kitchen == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginalef437a8846cea63fab15f4a3cdb9fa24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef437a8846cea63fab15f4a3cdb9fa24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.kitchen-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.kitchen-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef437a8846cea63fab15f4a3cdb9fa24)): ?>
<?php $attributes = $__attributesOriginalef437a8846cea63fab15f4a3cdb9fa24; ?>
<?php unset($__attributesOriginalef437a8846cea63fab15f4a3cdb9fa24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef437a8846cea63fab15f4a3cdb9fa24)): ?>
<?php $component = $__componentOriginalef437a8846cea63fab15f4a3cdb9fa24; ?>
<?php unset($__componentOriginalef437a8846cea63fab15f4a3cdb9fa24); ?>
<?php endif; ?>
            <span class="text-base">Cozinha</span>
        </div>
        <?php endif; ?>
        <?php if($pantry == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal820ef55664149ef52ea4c65662c54d2a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal820ef55664149ef52ea4c65662c54d2a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.pantry-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.pantry-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal820ef55664149ef52ea4c65662c54d2a)): ?>
<?php $attributes = $__attributesOriginal820ef55664149ef52ea4c65662c54d2a; ?>
<?php unset($__attributesOriginal820ef55664149ef52ea4c65662c54d2a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal820ef55664149ef52ea4c65662c54d2a)): ?>
<?php $component = $__componentOriginal820ef55664149ef52ea4c65662c54d2a; ?>
<?php unset($__componentOriginal820ef55664149ef52ea4c65662c54d2a); ?>
<?php endif; ?>
            <span class="text-base">Despensa</span>
        </div>
        <?php endif; ?>
        <?php if($electricOven == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal5599a9f5712959f709beb691096ae2e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5599a9f5712959f709beb691096ae2e2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.electric-oven-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.electric-oven-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5599a9f5712959f709beb691096ae2e2)): ?>
<?php $attributes = $__attributesOriginal5599a9f5712959f709beb691096ae2e2; ?>
<?php unset($__attributesOriginal5599a9f5712959f709beb691096ae2e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5599a9f5712959f709beb691096ae2e2)): ?>
<?php $component = $__componentOriginal5599a9f5712959f709beb691096ae2e2; ?>
<?php unset($__componentOriginal5599a9f5712959f709beb691096ae2e2); ?>
<?php endif; ?>
            <span class="text-base">Forno eléctrico</span>
        </div>
        <?php endif; ?>
        <?php if($gym == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginale7a23e25b77418d6dd46dc5a1f26d98e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7a23e25b77418d6dd46dc5a1f26d98e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.gym-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.gym-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7a23e25b77418d6dd46dc5a1f26d98e)): ?>
<?php $attributes = $__attributesOriginale7a23e25b77418d6dd46dc5a1f26d98e; ?>
<?php unset($__attributesOriginale7a23e25b77418d6dd46dc5a1f26d98e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7a23e25b77418d6dd46dc5a1f26d98e)): ?>
<?php $component = $__componentOriginale7a23e25b77418d6dd46dc5a1f26d98e; ?>
<?php unset($__componentOriginale7a23e25b77418d6dd46dc5a1f26d98e); ?>
<?php endif; ?>
            <span class="text-base">Ginásio</span>
        </div>
        <?php endif; ?>
        <?php if($laundry == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal36b7530fac37cd0e8ffd4bc742ad6d91 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36b7530fac37cd0e8ffd4bc742ad6d91 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.laundromat-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.laundromat-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36b7530fac37cd0e8ffd4bc742ad6d91)): ?>
<?php $attributes = $__attributesOriginal36b7530fac37cd0e8ffd4bc742ad6d91; ?>
<?php unset($__attributesOriginal36b7530fac37cd0e8ffd4bc742ad6d91); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36b7530fac37cd0e8ffd4bc742ad6d91)): ?>
<?php $component = $__componentOriginal36b7530fac37cd0e8ffd4bc742ad6d91; ?>
<?php unset($__componentOriginal36b7530fac37cd0e8ffd4bc742ad6d91); ?>
<?php endif; ?>
            <span class="text-base">Lavandaria</span>
        </div>
        <?php endif; ?>
        <?php if($balcony == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal52580755c7f09e154954c85672740af2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52580755c7f09e154954c85672740af2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.balcony-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.balcony-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52580755c7f09e154954c85672740af2)): ?>
<?php $attributes = $__attributesOriginal52580755c7f09e154954c85672740af2; ?>
<?php unset($__attributesOriginal52580755c7f09e154954c85672740af2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52580755c7f09e154954c85672740af2)): ?>
<?php $component = $__componentOriginal52580755c7f09e154954c85672740af2; ?>
<?php unset($__componentOriginal52580755c7f09e154954c85672740af2); ?>
<?php endif; ?>
            <span class="text-base">Varanda</span>
        </div>
        <?php endif; ?>
        <?php if($serviceArea == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginalf65637bf7529c37bdd5676e8d3247ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65637bf7529c37bdd5676e8d3247ffc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.cleaning-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.cleaning-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65637bf7529c37bdd5676e8d3247ffc)): ?>
<?php $attributes = $__attributesOriginalf65637bf7529c37bdd5676e8d3247ffc; ?>
<?php unset($__attributesOriginalf65637bf7529c37bdd5676e8d3247ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65637bf7529c37bdd5676e8d3247ffc)): ?>
<?php $component = $__componentOriginalf65637bf7529c37bdd5676e8d3247ffc; ?>
<?php unset($__componentOriginalf65637bf7529c37bdd5676e8d3247ffc); ?>
<?php endif; ?>
            <span class="text-base">Área de serviço</span>
        </div>
        <?php endif; ?>
        <?php if($cctv == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal3955c082b448c994b550fee3b5b47b13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3955c082b448c994b550fee3b5b47b13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.security-camera-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.security-camera-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3955c082b448c994b550fee3b5b47b13)): ?>
<?php $attributes = $__attributesOriginal3955c082b448c994b550fee3b5b47b13; ?>
<?php unset($__attributesOriginal3955c082b448c994b550fee3b5b47b13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3955c082b448c994b550fee3b5b47b13)): ?>
<?php $component = $__componentOriginal3955c082b448c994b550fee3b5b47b13; ?>
<?php unset($__componentOriginal3955c082b448c994b550fee3b5b47b13); ?>
<?php endif; ?>
            <span class="text-base">CCTV</span>
        </div>
        <?php endif; ?>
        <?php if($equippedKitchen == 1): ?>
        <div class="flex items-center gap-2>
            <?php if (isset($component)) { $__componentOriginalef437a8846cea63fab15f4a3cdb9fa24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef437a8846cea63fab15f4a3cdb9fa24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.kitchen-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.kitchen-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef437a8846cea63fab15f4a3cdb9fa24)): ?>
<?php $attributes = $__attributesOriginalef437a8846cea63fab15f4a3cdb9fa24; ?>
<?php unset($__attributesOriginalef437a8846cea63fab15f4a3cdb9fa24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef437a8846cea63fab15f4a3cdb9fa24)): ?>
<?php $component = $__componentOriginalef437a8846cea63fab15f4a3cdb9fa24; ?>
<?php unset($__componentOriginalef437a8846cea63fab15f4a3cdb9fa24); ?>
<?php endif; ?>
            <span class="text-base">Cozinha equipada</span>
        </div>
        <?php endif; ?>
        <?php if($suit == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginalfcea0d386308ce5d89fc561e21860548 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfcea0d386308ce5d89fc561e21860548 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.suit-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.suit-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfcea0d386308ce5d89fc561e21860548)): ?>
<?php $attributes = $__attributesOriginalfcea0d386308ce5d89fc561e21860548; ?>
<?php unset($__attributesOriginalfcea0d386308ce5d89fc561e21860548); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfcea0d386308ce5d89fc561e21860548)): ?>
<?php $component = $__componentOriginalfcea0d386308ce5d89fc561e21860548; ?>
<?php unset($__componentOriginalfcea0d386308ce5d89fc561e21860548); ?>
<?php endif; ?>
            <span class="text-base">Suit</span>
        </div>
        <?php endif; ?>
        <?php if($acclimatized == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal6334934444bcbfa992f006cfc4c13bd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6334934444bcbfa992f006cfc4c13bd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.air-conditioning-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.air-conditioning-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6334934444bcbfa992f006cfc4c13bd0)): ?>
<?php $attributes = $__attributesOriginal6334934444bcbfa992f006cfc4c13bd0; ?>
<?php unset($__attributesOriginal6334934444bcbfa992f006cfc4c13bd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6334934444bcbfa992f006cfc4c13bd0)): ?>
<?php $component = $__componentOriginal6334934444bcbfa992f006cfc4c13bd0; ?>
<?php unset($__componentOriginal6334934444bcbfa992f006cfc4c13bd0); ?>
<?php endif; ?>
            <span class="text-base">Ar condicionado</span>
        </div>
        <?php endif; ?>
        
        <?php if($guard == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginalee9e05f9e031b49fb61fc445e0c60894 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee9e05f9e031b49fb61fc445e0c60894 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.staff-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.staff-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee9e05f9e031b49fb61fc445e0c60894)): ?>
<?php $attributes = $__attributesOriginalee9e05f9e031b49fb61fc445e0c60894; ?>
<?php unset($__attributesOriginalee9e05f9e031b49fb61fc445e0c60894); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee9e05f9e031b49fb61fc445e0c60894)): ?>
<?php $component = $__componentOriginalee9e05f9e031b49fb61fc445e0c60894; ?>
<?php unset($__componentOriginalee9e05f9e031b49fb61fc445e0c60894); ?>
<?php endif; ?>
            <span class="text-base">Guarda</span>
        </div>
        <?php endif; ?>
        <?php if($twentyForHourSecurity == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal5a4a524b17720b96432c3546c9e76fac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5a4a524b17720b96432c3546c9e76fac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.shield-check-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.shield-check-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5a4a524b17720b96432c3546c9e76fac)): ?>
<?php $attributes = $__attributesOriginal5a4a524b17720b96432c3546c9e76fac; ?>
<?php unset($__attributesOriginal5a4a524b17720b96432c3546c9e76fac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5a4a524b17720b96432c3546c9e76fac)): ?>
<?php $component = $__componentOriginal5a4a524b17720b96432c3546c9e76fac; ?>
<?php unset($__componentOriginal5a4a524b17720b96432c3546c9e76fac); ?>
<?php endif; ?>
            <span class="text-base">Segurança 24hr</span>
        </div>
        <?php endif; ?>
        <?php if($receptionArea == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal1e933360df82fa00d60d68f843b2b010 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e933360df82fa00d60d68f843b2b010 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.reception-area-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.reception-area-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e933360df82fa00d60d68f843b2b010)): ?>
<?php $attributes = $__attributesOriginal1e933360df82fa00d60d68f843b2b010; ?>
<?php unset($__attributesOriginal1e933360df82fa00d60d68f843b2b010); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e933360df82fa00d60d68f843b2b010)): ?>
<?php $component = $__componentOriginal1e933360df82fa00d60d68f843b2b010; ?>
<?php unset($__componentOriginal1e933360df82fa00d60d68f843b2b010); ?>
<?php endif; ?>
            <span class="text-base">Área de recepção</span>
        </div>
        <?php endif; ?>
        <?php if($livingRoom == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal57b9669ed4026afb86f1a801d1e25330 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b9669ed4026afb86f1a801d1e25330 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.living-room-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.living-room-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b9669ed4026afb86f1a801d1e25330)): ?>
<?php $attributes = $__attributesOriginal57b9669ed4026afb86f1a801d1e25330; ?>
<?php unset($__attributesOriginal57b9669ed4026afb86f1a801d1e25330); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b9669ed4026afb86f1a801d1e25330)): ?>
<?php $component = $__componentOriginal57b9669ed4026afb86f1a801d1e25330; ?>
<?php unset($__componentOriginal57b9669ed4026afb86f1a801d1e25330); ?>
<?php endif; ?>
            <span class="text-base">Sala de estar</span>
        </div>
        <?php endif; ?>
        <?php if($terrace == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal586e25f948de3329e159788f99c9aa60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal586e25f948de3329e159788f99c9aa60 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.terrace-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.terrace-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal586e25f948de3329e159788f99c9aa60)): ?>
<?php $attributes = $__attributesOriginal586e25f948de3329e159788f99c9aa60; ?>
<?php unset($__attributesOriginal586e25f948de3329e159788f99c9aa60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal586e25f948de3329e159788f99c9aa60)): ?>
<?php $component = $__componentOriginal586e25f948de3329e159788f99c9aa60; ?>
<?php unset($__componentOriginal586e25f948de3329e159788f99c9aa60); ?>
<?php endif; ?>
            <span class="text-base">Terraço</span>
        </div>
        <?php endif; ?>
        <?php if($elevator == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginalf6ea19eedc515c7786c5f0a8fd2c2f8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6ea19eedc515c7786c5f0a8fd2c2f8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.elevator-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.elevator-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6ea19eedc515c7786c5f0a8fd2c2f8e)): ?>
<?php $attributes = $__attributesOriginalf6ea19eedc515c7786c5f0a8fd2c2f8e; ?>
<?php unset($__attributesOriginalf6ea19eedc515c7786c5f0a8fd2c2f8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6ea19eedc515c7786c5f0a8fd2c2f8e)): ?>
<?php $component = $__componentOriginalf6ea19eedc515c7786c5f0a8fd2c2f8e; ?>
<?php unset($__componentOriginalf6ea19eedc515c7786c5f0a8fd2c2f8e); ?>
<?php endif; ?>
            <span class="text-base">Elevador</span>
        </div>
        <?php endif; ?>
        <?php if($buildInStove == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginalb8b2c2088bfb4d9696a0cce4967a47ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb8b2c2088bfb4d9696a0cce4967a47ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.cooktop-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.cooktop-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb8b2c2088bfb4d9696a0cce4967a47ea)): ?>
<?php $attributes = $__attributesOriginalb8b2c2088bfb4d9696a0cce4967a47ea; ?>
<?php unset($__attributesOriginalb8b2c2088bfb4d9696a0cce4967a47ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb8b2c2088bfb4d9696a0cce4967a47ea)): ?>
<?php $component = $__componentOriginalb8b2c2088bfb4d9696a0cce4967a47ea; ?>
<?php unset($__componentOriginalb8b2c2088bfb4d9696a0cce4967a47ea); ?>
<?php endif; ?>
            <span class="text-base">Fogão embutido</span>
        </div>
        <?php endif; ?>
        <?php if($desk == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginalc31b5e31510de2415d7898a2d48dbe79 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc31b5e31510de2415d7898a2d48dbe79 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.dining-table-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.dining-table-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc31b5e31510de2415d7898a2d48dbe79)): ?>
<?php $attributes = $__attributesOriginalc31b5e31510de2415d7898a2d48dbe79; ?>
<?php unset($__attributesOriginalc31b5e31510de2415d7898a2d48dbe79); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc31b5e31510de2415d7898a2d48dbe79)): ?>
<?php $component = $__componentOriginalc31b5e31510de2415d7898a2d48dbe79; ?>
<?php unset($__componentOriginalc31b5e31510de2415d7898a2d48dbe79); ?>
<?php endif; ?>
            <span class="text-base">Mesa</span>
        </div>
        <?php endif; ?>
        <?php if($courtyard == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginala719c22d5f80d71c4b16a41b203aad0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala719c22d5f80d71c4b16a41b203aad0d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.courtyard-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.courtyard-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala719c22d5f80d71c4b16a41b203aad0d)): ?>
<?php $attributes = $__attributesOriginala719c22d5f80d71c4b16a41b203aad0d; ?>
<?php unset($__attributesOriginala719c22d5f80d71c4b16a41b203aad0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala719c22d5f80d71c4b16a41b203aad0d)): ?>
<?php $component = $__componentOriginala719c22d5f80d71c4b16a41b203aad0d; ?>
<?php unset($__componentOriginala719c22d5f80d71c4b16a41b203aad0d); ?>
<?php endif; ?>
            <span class="text-base">Pátio</span>
        </div>
        <?php endif; ?>
        <?php if($attachments == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal34956bd0ef14c2b22d8e4eb176043025 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34956bd0ef14c2b22d8e4eb176043025 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.attachments-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.attachments-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34956bd0ef14c2b22d8e4eb176043025)): ?>
<?php $attributes = $__attributesOriginal34956bd0ef14c2b22d8e4eb176043025; ?>
<?php unset($__attributesOriginal34956bd0ef14c2b22d8e4eb176043025); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34956bd0ef14c2b22d8e4eb176043025)): ?>
<?php $component = $__componentOriginal34956bd0ef14c2b22d8e4eb176043025; ?>
<?php unset($__componentOriginal34956bd0ef14c2b22d8e4eb176043025); ?>
<?php endif; ?>
            <span class="text-base">Anexos</span>
        </div>
        <?php endif; ?>
        <?php if($garden == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal24a88e3c2a75a17a9b86e771380835ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal24a88e3c2a75a17a9b86e771380835ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.garden-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.garden-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal24a88e3c2a75a17a9b86e771380835ef)): ?>
<?php $attributes = $__attributesOriginal24a88e3c2a75a17a9b86e771380835ef; ?>
<?php unset($__attributesOriginal24a88e3c2a75a17a9b86e771380835ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24a88e3c2a75a17a9b86e771380835ef)): ?>
<?php $component = $__componentOriginal24a88e3c2a75a17a9b86e771380835ef; ?>
<?php unset($__componentOriginal24a88e3c2a75a17a9b86e771380835ef); ?>
<?php endif; ?>
            <span class="text-base">Jardim</span>
        </div>
        <?php endif; ?>
        <?php if($furnished == 1): ?>
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal8e61203594149cbf71e0004f995039de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e61203594149cbf71e0004f995039de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.furnished-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.furnished-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e61203594149cbf71e0004f995039de)): ?>
<?php $attributes = $__attributesOriginal8e61203594149cbf71e0004f995039de; ?>
<?php unset($__attributesOriginal8e61203594149cbf71e0004f995039de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e61203594149cbf71e0004f995039de)): ?>
<?php $component = $__componentOriginal8e61203594149cbf71e0004f995039de; ?>
<?php unset($__componentOriginal8e61203594149cbf71e0004f995039de); ?>
<?php endif; ?>
            <span class="text-base">Mobiliada</span>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /home/casacoim/imoveis.casacoimbramaputo.com/resources/views/components/comfort.blade.php ENDPATH**/ ?>