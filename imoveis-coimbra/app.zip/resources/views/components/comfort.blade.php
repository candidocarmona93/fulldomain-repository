<section id="comodidades">
    <h3 class="font-medium text-2xl mb-2 text-[#222]">Comodidades</h3>
    <div class="grid xl:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-4">
        @if($car == 1)
        <div class="flex items-center gap-2" >
            <x-icons.car-icon />
            <span class="text-base">Garagem de carro</span>
        </div>
        @endif
        @if($pool == 1)
        <div class="flex items-center gap-2">
            <x-icons.pool-icon />
            <span class="text-base">Piscina</span>
        </div>
        @endif
        @if($cave == 1)
        <div class="flex items-center gap-2">
            <x-icons.basement-icon class="h-5"/>
            <span class="text-base">Cave</span>
        </div>
        @endif
        @if($wifi == 1)
        <div class="flex items-center gap-2">
            <x-icons.wifi-icon class="h-5"/>
            <span class="text-base">Wi-Fi</span>
        </div>
        @endif
        @if($park == 1)
        <div class="flex items-center gap-2">
            <x-icons.park-icon />
            <span class="text-base">Parque</span>
        </div>
        @endif
        @if($kitchen == 1)
        <div class="flex items-center gap-2">
            <x-icons.kitchen-icon />
            <span class="text-base">Cozinha</span>
        </div>
        @endif
        @if($pantry == 1)
        <div class="flex items-center gap-2">
            <x-icons.pantry-icon />
            <span class="text-base">Despensa</span>
        </div>
        @endif
        @if($electricOven == 1)
        <div class="flex items-center gap-2">
            <x-icons.electric-oven-icon />
            <span class="text-base">Forno eléctrico</span>
        </div>
        @endif
        @if($gym == 1)
        <div class="flex items-center gap-2">
            <x-icons.gym-icon/>
            <span class="text-base">Ginásio</span>
        </div>
        @endif
        @if($laundry == 1)
        <div class="flex items-center gap-2">
            <x-icons.laundromat-icon />
            <span class="text-base">Lavandaria</span>
        </div>
        @endif
        @if($balcony == 1)
        <div class="flex items-center gap-2">
            <x-icons.balcony-icon />
            <span class="text-base">Varanda</span>
        </div>
        @endif
        @if($serviceArea == 1)
        <div class="flex items-center gap-2">
            <x-icons.cleaning-icon />
            <span class="text-base">Área de serviço</span>
        </div>
        @endif
        @if($cctv == 1)
        <div class="flex items-center gap-2">
            <x-icons.security-camera-icon />
            <span class="text-base">CCTV</span>
        </div>
        @endif
        @if($equippedKitchen == 1)
        <div class="flex items-center gap-2>
            <x-icons.kitchen-icon />
            <span class="text-base">Cozinha equipada</span>
        </div>
        @endif
        @if($suit == 1)
        <div class="flex items-center gap-2">
            <x-icons.suit-icon />
            <span class="text-base">Suit</span>
        </div>
        @endif
        @if($acclimatized == 1)
        <div class="flex items-center gap-2">
            <x-icons.air-conditioning-icon />
            <span class="text-base">Ar condicionado</span>
        </div>
        @endif
        {{-- @if($generator == 1)
        <div class="flex items-center gap-2">
            <span class="text-base">Gerador</span>
        </div>
        @endif --}}
        @if($guard == 1)
        <div class="flex items-center gap-2">
            <x-icons.staff-icon />
            <span class="text-base">Guarda</span>
        </div>
        @endif
        @if($twentyForHourSecurity == 1)
        <div class="flex items-center gap-2">
            <x-icons.shield-check-icon />
            <span class="text-base">Segurança 24hr</span>
        </div>
        @endif
        @if($receptionArea == 1)
        <div class="flex items-center gap-2">
            <x-icons.reception-area-icon />
            <span class="text-base">Área de recepção</span>
        </div>
        @endif
        @if($livingRoom == 1)
        <div class="flex items-center gap-2">
            <x-icons.living-room-icon />
            <span class="text-base">Sala de estar</span>
        </div>
        @endif
        @if($terrace == 1)
        <div class="flex items-center gap-2">
            <x-icons.terrace-icon />
            <span class="text-base">Terraço</span>
        </div>
        @endif
        @if($elevator == 1)
        <div class="flex items-center gap-2">
            <x-icons.elevator-icon />
            <span class="text-base">Elevador</span>
        </div>
        @endif
        @if($buildInStove == 1)
        <div class="flex items-center gap-2">
            <x-icons.cooktop-icon />
            <span class="text-base">Fogão embutido</span>
        </div>
        @endif
        @if($desk == 1)
        <div class="flex items-center gap-2">
            <x-icons.dining-table-icon />
            <span class="text-base">Mesa</span>
        </div>
        @endif
        @if($courtyard == 1)
        <div class="flex items-center gap-2">
            <x-icons.courtyard-icon />
            <span class="text-base">Pátio</span>
        </div>
        @endif
        @if($attachments == 1)
        <div class="flex items-center gap-2">
            <x-icons.attachments-icon />
            <span class="text-base">Anexos</span>
        </div>
        @endif
        @if($garden == 1)
        <div class="flex items-center gap-2">
            <x-icons.garden-icon />
            <span class="text-base">Jardim</span>
        </div>
        @endif
        @if($furnished == 1)
        <div class="flex items-center gap-2">
            <x-icons.furnished-icon />
            <span class="text-base">Mobiliada</span>
        </div>
        @endif
    </div>
</section>
