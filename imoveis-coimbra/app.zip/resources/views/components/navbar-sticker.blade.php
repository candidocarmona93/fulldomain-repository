<section class="sticky top-[4rem] z-10">
    <div class="md:block hidden bg-white border-b-2 border-[#CACACA] mt-10">
        <div class="grid grid-cols-12">
            <div class="col-start-2 col-end-10">
                <div class="nav-sticker space-x-5 font-medium flex items-center">
                    <p class="fotos py-4 text-[#b3b3b3] active cursor-pointer hover:text-[#222]">
                        <a href="#fotos">Fotos</a>
                    </p>
                    <p class="comodidades py-4 text-[#b3b3b3] cursor-pointer hover:text-[#222]">
                        <a href="#comodidades">Comodidades</a>
                    </p>
                    <p class="comentarios py-4 text-[#b3b3b3] cursor-pointer hover:text-[#222]">
                        <a href="#comentarios">Comentários</a>
                    </p>
                    <p class="localizacao py-4 text-[#b3b3b3] cursor-pointer hover:text-[#222]">
                        <a href="#localizacao">Localização</a>
                    </p>
                </div>
            </div>
            <div class="col-start-11 col-end-12">
                <div class="flex gap-5 py-3 font-medium">
                    <div class="flex items-center gap-2 border text-[#1484FF] border-[#1484FF] hover:bg-[#1484FF] hover:text-white transition-all ease-in-out rounded-lg px-2 py-1 cursor-pointer" data-ripple-light="true" data-dialog-target="share">
                        <x-icons.share-icon />
                        <span class="text-base">Partilhar</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<x-modal.default name="share" maxWidth="max-w-xl">
    <x-slot:body>
        <x-modal.share :title="$title" :url="$url" :picture="$image" />
    </x-slot:body>
</x-modal.default>
<style>
    .active {
        color: #222!important;
    }
    html {
        scroll-behavior: smooth;
    }
</style>
<script>
    const sections = document.querySelectorAll("section");
    const navA = document.querySelectorAll(".nav-sticker p");

    window.onscroll = () => {
        var current = "";

        sections.forEach((section) => {
            const sectionTop = section.offsetTop;
            if (pageYOffset >= sectionTop - 120) {
                current = section.getAttribute("id");
            }
        });

        navA.forEach((p) => {
            p.classList.remove("active");
            if (p.classList.contains(current)) {
                p.classList.add("active");
            }
        });
    };
</script>
