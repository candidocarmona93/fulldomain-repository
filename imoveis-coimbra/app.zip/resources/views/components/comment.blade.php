<section id="comentarios">
    <div class="flex gap-1 items-center">
        <x-icons.star-icon />
        <span class="text-2xl font-medium text-[#222]">{{ $comments }} comentários</span>
    </div>
    @if($comments > 0)
    <div class="grid grid-cols-2 my-4 space-y-6">
        <div class="col-span-1" v-for="comment in comments">
            <h4 class="font-bold text-[#222]">{{ $comment->summary }}</h4>
            <div class="space-y-2 mt-3">
                <p>{{ comment.analysis }}</p>
                <p class="text-[#808080]">{{ $comment->nickname }}</p>
            </div>
        </div>
    </div>
    @endif
    <h3 class="text-lg text-center py-3 mt-3 bg-slate-100/50 text-slate-500 font-medium rounded-lg" v-else>
        Sem comentários
    </h3>
</section>
