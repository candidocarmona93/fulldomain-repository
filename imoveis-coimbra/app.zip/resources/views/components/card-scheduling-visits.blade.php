<div class="{{$cborder ?? 'border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700 bg-white rounded-xl'}} {{$maxwidth ?? 'w-80'}}">
    <div class="p-5">
        <h5 class="text-xl font-bold tracking-tight text-gray-900 dark:text-white" id="title">Agendar vista</h5>
        <form method="POST" id="form-visits">
            <div class="space-y-4 my-6">
                <div>
                    <div class="gap-[4px] inline-flex flex-col px-2 py-1 border border-[#999] rounded-md w-full">
                        <label class="text-sm">Data de marcação</label>
                        <input type="text" id="data"/>
                    </div>
                    <div class="text-red-600 mt-1 text-sm is_invalid" id="is_invalid_data"></div>
                </div>
                <div>
                    <input type="text" class="bg-gray-50 text-gray-900 text-sm rounded-lg dark:text-white focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 border border-[#999]" name="nome" id="nome" placeholder="Seu nome">
                    <div class="text-red-600 mt-1 text-sm is_invalid" id="is_invalid_nome"></div>
                </div>
                <div>
                    <input type="email" class="bg-gray-50 text-gray-900 text-sm rounded-lg dark:text-white focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 border border-[#999]" name="email" id="email" placeholder="sis@casacoimbramaputo.com">
                    <div class="text-red-600 mt-1 text-sm is_invalid" id="is_invalid_email"></div>
                </div>
                <div>
                    <input type="text" class="bg-gray-50 text-gray-900 text-sm rounded-lg dark:text-white focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 border border-[#999]" name="contacto" id="contacto" placeholder="+258 82 XXX XXXX">
                    <div class="text-red-600 mt-1 text-sm is_invalid" id="is_invalid_contacto"></div>
                </div>
            </div>
            <button type="submit" id="btn-visits" class="w-full items-center px-3 py-2 text-sm font-medium text-center text-white bg-[#1484FF] rounded-lg hover:bg-blue-600 focus:ring-0 focus:outline-none dark:bg-blue-600 dark:hover:bg-blue-500 dark:focus:ring-blue-800">Marcar</button>
        </form>
        <div id="message"></div>
    </div>
</div>
<style>
    <style lang="css">
    .dp__input {
        border: 0px;
        padding-top: 2px;
        padding-bottom: 2px;
    }
</style>
<script src="{{asset('./plugins/jquery/jquery-3.3.1.min.js')}}"></script>
<script src="{{asset('./plugins/jquery.datetimepicker/jquery.datetimepicker.js')}}"></script>
<script>
    $(document).ready(function() {
        const today = new Date();
        let data = `${String(today.getDate()).padStart(2, '0')}-${String(today.getMonth() + 1).padStart(2, '0')}-${today.getFullYear()}`;
        let hora = `${String(today.getHours()).padStart(2, '0')}:${String(today.getMinutes()).padStart(2, '0')}:${String(today.getSeconds()).padStart(2, '0')}`;

        $('#data').datetimepicker({
            ownerDocument: document,
            contentWindow: window,

            value: `${data} ${hora}`,

            format:'d-m-Y H:i:s',
            formatTime:'H:i',
            formatDate:'d-m-Y',
        });

        $("#form-visits").submit(function(e) {
            e.preventDefault();
            const self = this;
            var fullDataString = $("#data").val().split(" ");
            var dateAr = fullDataString[0].split('-');

            $.ajax({
                url: 'https://workspace.casacoimbramaputo.com/api/save-scheduling-visits',
                method: 'POST',
                data: {
                    slug: "{{$slug}}",
                    data: `${dateAr[2]}/${dateAr[1]}/${dateAr[0]}`,
                    hora: fullDataString[1],
                    nome: $("#nome").val(),
                    email: $("#email").val(),
                    contacto: $("#contacto").val(),
                },
                dataType: 'json',
                processData: true,
                before: function(b) {
                    $('#btn-visits').attr('disabled', false);
                    $('#btn-visits').html('A enviar...');
                },
                success: function(response) {
                    $(self)[0].reset();
                    $(".is_invalid").html("");
                    $('#btn-visits').attr('disabled', false);
                    $('#btn-visits').html('Marcar');
                    $("#data").val(`${data} ${hora}`);
                    $("#message").html(`<div class="bg-green-300 my-2 px-3 py-2 rounded-lg border-2 border-green-400 text-green-600 flex items-center justify-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" class="h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> A sua marcação foi enviada</div>`);
                },
                error: function(xhr) {
                    $('#btn-visits').attr('disabled', false);
                    $('#btn-visits').html('Marcar');
                    if(xhr.status === 422) {
                        $(".is_invalid").html("");
                        $.each(xhr.responseJSON['errors'], function(key, res) {
                            $(`#is_invalid_${key}`).html(res);
                        });
                    }

                    if(xhr.status === 500) {
                        console.log(xhr.responseJSON)
                    }
                }
            });
        });
    });
</script>
