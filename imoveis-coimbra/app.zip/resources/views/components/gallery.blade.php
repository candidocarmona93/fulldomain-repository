<div>
    <div class="swiper mySwiper">
        <div class="swiper-wrapper">
            @foreach($items as $item)
            <div class="swiper-slide">
                <img class="object-cover h-80 w-full" src="https://workspace.casacoimbramaputo.com/uploads/immobiles/{{$code}}/{{$item->picture}}" />
            </div>
            @endforeach
        </div>

        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>

        <div class="swiper-scrollbar"></div>

        <button type="button" class="flex gap-2 items-center bg-white border-2 border-[#222] text-[#222] text-sm font-semibold rounded-lg px-[13px] py-[7px] hover:text-slate-700 absolute right-[56px] bottom-5 z-10">
            <x-icons.squares-2-x-2-icon />
            Ver todas images
        </button>
    </div>
</div>
<link rel="stylesheet" href="{{asset('./plugins/swiper/css/swiper-bundle.min.css')}}">
<script src="{{asset('./plugins/jquery/jquery-3.3.1.min.js')}}"></script>
<script src="{{asset('./plugins/swiper/js/swiper-bundle.min.js')}}"></script>
<script>
    $(document).ready(function(){
        const sw = new Swiper('.mySwiper', {
            breakpoints: {
                320: {
                    slidesPerView: 1,
                    spaceBetween: 3
                },
                640: {
                    slidesPerView: 2,
                    spaceBetween: 4
                },
                1280: {
                    slidesPerView: 3,
                    spaceBetween: 5
                }
            },
            freeMode: true,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            scrollbar: {
                el: '.swiper-scrollbar',
                draggable: true,
                dragSize: 200,
            },
        });
    })
</script>
