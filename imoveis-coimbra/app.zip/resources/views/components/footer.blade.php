<div class="bg-[#F7F7F7] py-[13px] border-t-2 border-t-[#DDD] sm:mb-0 mb-[54px] loading-show">
    <div class="container mx-auto px-6">
        <div class="grid grid-cols-12 sm:my-16 my-8 sm:space-y-0 space-y-4">
            <div class="md:col-start-2 md:col-end-5 sm:col-start-2 sm:col-end-4 col-span-12 sm:space-y-4 space-y-2">
                <h3 class="font-semibold text-lg">Apoio</h3>
                <div class="flex flex-col gap-2">
                    <a href="https://casacoimbramaputo.com/centro-de-apoio" class="text-sm text-[#222] hover:text-[#808080]">Centro de Apoio</a>
                </div>
            </div>
            <div class="md:col-start-6 md:col-end-8 sm:col-start-5 sm:col-end-7 col-span-12 sm:space-y-4 space-y-2">
                <h3 class="font-semibold text-lg">Casa Coimbra Maputo</h3>
                <div class="flex flex-col gap-2">
                    <a href="https://casacoimbramaputo.com/host" class="text-sm text-[#222] hover:text-[#808080]">Minha casa</a>
                    <a href="https://casacoimbramaputo.com/eu-sou-o-dono" class="text-sm text-[#222] hover:text-[#808080]">Eu Sou O Dono</a>
                    <a href="https://casacoimbramaputo.com/parceiros" class="text-sm text-[#222] hover:text-[#808080]">Parceiros</a>
                </div>
            </div>
            <div class="md:col-start-10 md:col-end-12 sm:col-start-8 sm:col-end-12 col-span-12 sm:space-y-4 space-y-2">
                <h3 class="font-semibold text-lg">Contacto</h3>
                <div class="flex flex-col gap-2">
                    <span class="text-sm">
                        <a href="tel:+258 84 016 9593">
                            +258 84 016 9593
                        </a>
                    </span>
                    <span class="text-sm">
                        <a href="mailto:info@casacoimbramaputo.com">
                            info@casacoimbramaputo.com
                        </a>
                    </span>
                    <span class="text-sm">Praceta de Diu, Av. Maguiguana, N°26 R/C, Maputo, Moçambique</span>
                </div>
            </div>
        </div>
        <hr class="w-full h-1 bg-[#DDD] border-0 rounded">
        <div class="grid grid-cols-12 pt-[13px] text-[#222]">
            <div class="sm:col-span-9 col-span-12 flex gap-[10px] sm:flex-row flex-col">
                <span><script>document.write(new Date().getFullYear())</script> &copy; Casa Coimbra Maputo</span>
                <a href="#" class="hover:text-[#808080]">Termos</a>
                <a href="#" class="hover:text-[#808080]">Mapa do site</a>
            </div>
            <div class="sm:col-span-3 col-span-12 flex flex-col sm:flex-row sm:space-x-6 sm:justify-end sm:space-y-0 space-y-3 mt-3 sm:mt-0">
                <div class="flex items-center gap-1 sm:hover:bg-[#e7e7e7] rounded-lg sm:px-2 cursor-pointer">
                    <x-icons.globe-alt-icon class="h-5" />
                    <span class="md:block sm:hidden block">Português</span>
                    <span class="md:hidden sm:block hidden">PT</span>
                </div>
                <div class="flex gap-2">
                    <a class="text-[#222] hover:text-[#808080]" href="https://wa.me/+258840169593" target="_blank">
                        <x-icons.whatsapp-icon />
                    </a>
                    <a class="text-[#222] hover:text-[#808080]" href="https://www.facebook.com/CasacoimbraMaputo/about/" target="_blank">
                        <x-icons.facebook-icon />
                    </a>
                    <a class="text-[#222] hover:text-[#808080]" href="https://www.instagram.com/casa_coimbra_maputo/" target="_blank">
                        <x-icons.instagram-icon />
                    </a>
                    <a class="text-[#222] hover:text-[#808080]" href="https://www.youtube.com/@pedrocoimbrarealestateguru5726" target="_blank">
                        <x-icons.youtube />
                    </a>
                    <a class="text-[#222] hover:text-[#808080]" href="https://mz.linkedin.com/in/casa-coimbra-real-estate-maputo-5706601a7" target="_blank">
                        <x-icons.linkedin-in-icon />
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
