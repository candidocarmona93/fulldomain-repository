@extends('layouts.app')
{{-- <x-skeleton /> --}}
<x-navbar />
@foreach($immobiles as $immobile)
    <div class="relative p-5 loading-show">
        <div class="bg-gray-900/30 rounded-lg top-5 absolute bottom-0 left-5 right-5" style="height: calc(100vh - 110px);"></div>
        <img class="rounded-lg object-cover w-full" style="height: calc(100vh - 110px);" src="https://workspace.casacoimbramaputo.com/uploads/immobiles/{{$immobile->code}}/{{$immobile->picture}}" alt="{{$immobile->title}}">
        <div class="absolute px-10 text-lg text-white bottom-0 lg:py-5 py-16 right-5 left-5">
            <div class="lg:flex lg:flex-row lg:gap-2 lg:items-center">
                <img class="lg:block hidden" src="https://workspace.casacoimbramaputo.com/uploads/profiles/agents/{{$immobile->responsible->picture}}" alt="{{$immobile->responsible->name}}">
                <div class="lg:space-y-5 space-y-3 w-full">
                    <h5 class="font-semibold sm:text-4xl text-2xl">{{ $immobile->title }}</h5>
                    <hr class="h-1 w-12 bg-gradient-to-r from-blue-700 from-35% to-blue-500 to-65% border-0 rounded dark:bg-gray-70 flex-shrink-0">
                    <div class="flex items-center gap-2">
                        <x-icons.map-pin-icon />
                        <span class="text-base break-all">{{ $immobile->address }}</span>
                    </div>
                    <div class="grid grid-cols-12 sm:space-y-0 space-y-2">
                        <div class="xl:col-span-2 md:col-span-3 sm:col-span-2 col-span-12">
                            <div class="flex items-center gap-1 hover:underline">
                                <x-icons.whatsapp-icon />
                                <a href="https://wa.me/+258840169593?text=https://casacoimbramaputo.com/imoveis/{{$immobile->slug}}" target="__blank">
                                    <span class="text-base break-all">+258 84 016 9593</span>
                                </a>
                            </div>
                        </div>
                        <div class="xl:col-span-8 md:col-span-7 sm:col-span-8 col-span-12">
                            <a href='mailto:info@casacoimbramaputo.com' class="flex items-center gap-2 hover:underline">
                                <x-icons.envelope-icon />
                                <span class="text-base break-all">info@casacoimbramaputo.com</span>
                            </a>
                        </div>
                        <div class="xl:col-span-2 md:col-span-2 sm:col-span-2 col-span-12">
                            <div class="flex flex-row items-center gap-1 sm:justify-end">
                                <x-icons.eye-icon />
                                <span class="text-base break-all">{{ $immobile->views }} Visita(s)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mt-5 loading-show">
        <div class="container mx-auto mb-8">
            <div class="space-x-5 flex md:mx-0 sm:mx-5 mx-5">
                <a href="https://casacoimbramaputo.com" class="font-bold mb-0 cursor-pointer flex gap-1 items-center">
                    <x-icons.arrow-small-left-icon class="w-6" />
                    Voltar
                </a>
                <a class="text-base mb-0">{{ $immobile->title }}</a>
            </div>
        </div>
        <x-gallery :code="$immobile->code" :items="$gallery" />
        <x-navbar-sticker :title="$immobile->title" :url="$immobile->slug" :image="'https://workspace.casacoimbramaputo.com/uploads/immobiles/'.$immobile->code.'/'.$immobile->picture"/>
        <div class="container mx-auto sm:px-1 mt-7 mb-14">
            <div class="button-mobile flex md:hidden mb-5 gap-3">
                <button type="button" class="flex items-center justify-center gap-2 sm:mx-0 mx-5 px-4 py-2 text-sm font-medium text-white bg-[#1484FF] rounded-lg hover:bg-blue-600 focus:ring-0 focus:outline-none dark:bg-blue-600 dark:hover:bg-blue-500 dark:focus:ring-blue-800" data-ripple-light="true" data-dialog-target="scheduling">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
                        <path d="M12.75 12.75a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM7.5 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM8.25 17.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM9.75 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM10.5 17.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM12.75 17.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM14.25 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM15 17.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM16.5 15.75a.75.75 0 100-1.5.75.75 0 000 1.5zM15 12.75a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM16.5 13.5a.75.75 0 100-1.5.75.75 0 000 1.5z"></path>
                        <path fill-rule="evenodd" d="M6.75 2.25A.75.75 0 017.5 3v1.5h9V3A.75.75 0 0118 3v1.5h.75a3 3 0 013 3v11.25a3 3 0 01-3 3H5.25a3 3 0 01-3-3V7.5a3 3 0 013-3H6V3a.75.75 0 01.75-.75zm13.5 9a1.5 1.5 0 00-1.5-1.5H5.25a1.5 1.5 0 00-1.5 1.5v7.5a1.5 1.5 0 001.5 1.5h13.5a1.5 1.5 0 001.5-1.5v-7.5z" clip-rule="evenodd"></path>
                    </svg> Agendar visita
                </button>
                <button type="button" class="flex items-center gap-2 border text-white bg-[#1484FF] hover:text-white transition-all ease-in-out rounded-lg px-4 py-1 hover:bg-blue-600 focus:ring-0 focus:outline-none dark:bg-blue-600 dark:hover:bg-blue-500 dark:focus:ring-blue-800" data-ripple-light="true" data-dialog-target="share">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" style="width:1.25rem; height:1.25rem;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186l9.566-5.314m-9.566 7.5l9.566 5.314m0 0a2.25 2.25 0 103.935 2.186 2.25 2.25 0 00-3.935-2.186zm0-12.814a2.25 2.25 0 103.933-2.185 2.25 2.25 0 00-3.933 2.185z"></path>
                    </svg> Partilhar
                </button>
            </div>

            <div class="grid grid-cols-12 sm:mx-0 mx-5">
                <div class="col-span-8 space-y-7">
                    <div class="text-base font-normal">
                        {!! $immobile->description !!}
                    </div>
                    <hr class="sm:block hidden">
                    <x-comfort
                        :car="$immobile->car"
                        :pool="$immobile->pool"
                        :cave="$immobile->cave"
                        :wifi="$immobile->wifi"
                        :park="$immobile->park"
                        :kitchen="$immobile->kitchen"
                        :pantry="$immobile->pantry"
                        :electricOven="$immobile->electric_oven"
                        :gym="$immobile->gym"
                        :laundry="$immobile->laundry"
                        :balcony="$immobile->balcony"
                        :serviceArea="$immobile->service_area"
                        :cctv="$immobile->cctv"
                        :equippedKitchen="$immobile->equipped_kitchen"
                        :suit="$immobile->suit"
                        :acclimatized="$immobile->acclimatized"
                        :generator="$immobile->generator"
                        :guard="$immobile->guard"
                        :twentyForHourSecurity="$immobile->twenty_for_hour_security"
                        :receptionArea="$immobile->reception_area"
                        :livingRoom="$immobile->living_room"
                        :terrace="$immobile->terrace"
                        :buildInStove="$immobile->build_in_stove"
                        :elevator="$immobile->elevator"
                        :desk="$immobile->desk"
                        :courtyard="$immobile->courtyard"
                        :attachments="$immobile->attachments"
                        :garden="$immobile->garden"
                        :furnished="$immobile->furnished"
                    />
                </div>
                <div class="col-span-4 mx-auto md:block hidden">
                    <x-card-scheduling-visits :slug="$immobile->slug" />
                </div>
            </div>
            <div class="sm:mx-0 mx-5">
                <hr class="my-7">
                <x-comment
                    comments="0"
                />
                <hr class="my-7 w-full">
            </div>
            <section class="space-y-3" id="localizacao">
                <h3 class="text-2xl font-semibold text-[#222] sm:mx-0 mx-5">Onde estará</h3>
                <h3 class="text-base text-[#222] sm:mx-0 mx-5">{{ $immobile->address }}</h3>
                <div class="map">
                    <x-map-view
                        :lat="$immobile->latitude"
                        :long="$immobile->longitude"
                    />
                </div>
            </section>
        </div>
        <div class="bg-[#F7F7F7] py-6 border-t-2 border-t-[#DDD]">
            <div class="container mx-auto">
                <span class="sm:mx-0 mx-5 flex items-center gap-1">
                    <a href="/" class="text-sm">Casa Coimbra Maputo</a>
                    <x-icons.chevron-right-icon />
                    <span class="text-sm">{{ $immobile->address }}</span>
                </span>
            </div>
        </div>
    </div>
    <x-modal.default name="scheduling" maxWidth="max-w-xl">
        <x-slot:body>
            <x-card-scheduling-visits maxwidth="w-full" cborder="border-0" :slug="$immobile->slug" />
        </x-slot:body>
    </x-modal.default>
    <a aria-label="Chat on WhatsApp" class="float pulse" href="https://wa.me/+258840169593?text=Olá 👋🏽!%20Mais%20infotmações%20sobre%20{{ $immobile->title }}." target="_blank">
            <svg class="svg" fill="#000000" height="25px" width="25px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 308 308" xml:space="preserve">
                <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                <g id="SVGRepo_iconCarrier"> 
                    <g id="XMLID_468_"> 
                        <path id="XMLID_469_" d="M227.904,176.981c-0.6-0.288-23.054-11.345-27.044-12.781c-1.629-0.585-3.374-1.156-5.23-1.156 c-3.032,0-5.579,1.511-7.563,4.479c-2.243,3.334-9.033,11.271-11.131,13.642c-0.274,0.313-0.648,0.687-0.872,0.687 c-0.201,0-3.676-1.431-4.728-1.888c-24.087-10.463-42.37-35.624-44.877-39.867c-0.358-0.61-0.373-0.887-0.376-0.887 c0.088-0.323,0.898-1.135,1.316-1.554c1.223-1.21,2.548-2.805,3.83-4.348c0.607-0.731,1.215-1.463,1.812-2.153 c1.86-2.164,2.688-3.844,3.648-5.79l0.503-1.011c2.344-4.657,0.342-8.587-0.305-9.856c-0.531-1.062-10.012-23.944-11.02-26.348 c-2.424-5.801-5.627-8.502-10.078-8.502c-0.413,0,0,0-1.732,0.073c-2.109,0.089-13.594,1.601-18.672,4.802 c-5.385,3.395-14.495,14.217-14.495,33.249c0,17.129,10.87,33.302,15.537,39.453c0.116,0.155,0.329,0.47,0.638,0.922 c17.873,26.102,40.154,45.446,62.741,54.469c21.745,8.686,32.042,9.69,37.896,9.69c0.001,0,0.001,0,0.001,0 c2.46,0,4.429-0.193,6.166-0.364l1.102-0.105c7.512-0.666,24.02-9.22,27.775-19.655c2.958-8.219,3.738-17.199,1.77-20.458 C233.168,179.508,230.845,178.393,227.904,176.981z"></path> 
                        <path id="XMLID_470_" d="M156.734,0C73.318,0,5.454,67.354,5.454,150.143c0,26.777,7.166,52.988,20.741,75.928L0.212,302.716 c-0.484,1.429-0.124,3.009,0.933,4.085C1.908,307.58,2.943,308,4,308c0.405,0,0.813-0.061,1.211-0.188l79.92-25.396 c21.87,11.685,46.588,17.853,71.604,17.853C240.143,300.27,308,232.923,308,150.143C308,67.354,240.143,0,156.734,0z M156.734,268.994c-23.539,0-46.338-6.797-65.936-19.657c-0.659-0.433-1.424-0.655-2.194-0.655c-0.407,0-0.815,0.062-1.212,0.188 l-40.035,12.726l12.924-38.129c0.418-1.234,0.209-2.595-0.561-3.647c-14.924-20.392-22.813-44.485-22.813-69.677 c0-65.543,53.754-118.867,119.826-118.867c66.064,0,119.812,53.324,119.812,118.867 C276.546,215.678,222.799,268.994,156.734,268.994z"></path> 
                    </g> 
                </g>
            </svg>
        </a>

@endforeach
<x-footer />
<script>
    // $(document).ready(function() {
    //     setTimeout(function(){
    //         $(".animate-pulse").remove();
    //         $(".loading-show").css('display', 'grid');
    //     }, 5000);
    // })
</script>
