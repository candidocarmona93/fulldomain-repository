<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        {!! SEOMeta::generate() !!}
        {!! OpenGraph::generate() !!}
        {!! Twitter::generate() !!}
        {!! JsonLd::generate() !!}
        <link rel="stylesheet" href="{{asset('./plugins/jquery.datetimepicker/jquery.datetimepicker.css')}}">
        <link rel="stylesheet" href="{{asset('./css/app.css')}}">
        <!-- from cdn -->
        <script src="https://unpkg.com/@material-tailwind/html@latest/scripts/dialog.js"></script>
        <script src="{{asset('./js/app.js')}}"></script>
        <style>
            .float {
                position:fixed;
                width:60px;
                height:60px;
                bottom:40px;
                right:40px;
                background-color:rgb(37, 211, 102);
                color:#FFF;
                border-radius:50px;
                text-align:center;
                font-size:30px;
                box-shadow: 0 0 11px 3px #87878773;
                z-index:100;
            }
            .svg {
                fill: rgb(24, 24, 24);
                margin: auto;
                height: 100%;
            }
            .pulse {
                animation: pulse-animation 2s infinite;
            }
            @keyframes pulse-animation {
                0% {
                    box-shadow: 0 0 0 0px rgba(37, 211, 102, 0.6);
                }
                100% {
                    box-shadow: 0 0 0 20px rgba(37, 211, 102, 0);
                }
            }
        </style>
    </head>
    <body>
        <slot />
    </body>
</html>
